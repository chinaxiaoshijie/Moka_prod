--
-- PostgreSQL database dump
--

\restrict mu8x2NmCzIEpRhRTY46LXFzBcUVa1ZM9ablYgyYZO0lcCMkP9obitsNwfH3Qvnt

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CandidateSource; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."CandidateSource" AS ENUM (
    'BOSS',
    'REFERRAL',
    'HEADHUNTER',
    'WEBSITE'
);


ALTER TYPE public."CandidateSource" OWNER TO moka;

--
-- Name: CandidateStatus; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."CandidateStatus" AS ENUM (
    'PENDING',
    'SCREENING',
    'INTERVIEW_1',
    'INTERVIEW_2',
    'INTERVIEW_3',
    'HIRED',
    'REJECTED'
);


ALTER TYPE public."CandidateStatus" OWNER TO moka;

--
-- Name: FeedbackResult; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."FeedbackResult" AS ENUM (
    'PASS',
    'FAIL',
    'PENDING'
);


ALTER TYPE public."FeedbackResult" OWNER TO moka;

--
-- Name: InterviewFormat; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."InterviewFormat" AS ENUM (
    'ONLINE',
    'OFFLINE'
);


ALTER TYPE public."InterviewFormat" OWNER TO moka;

--
-- Name: InterviewStatus; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."InterviewStatus" AS ENUM (
    'SCHEDULED',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."InterviewStatus" OWNER TO moka;

--
-- Name: InterviewType; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."InterviewType" AS ENUM (
    'INTERVIEW_1',
    'INTERVIEW_2',
    'INTERVIEW_3'
);


ALTER TYPE public."InterviewType" OWNER TO moka;

--
-- Name: MentionStatus; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."MentionStatus" AS ENUM (
    'PENDING',
    'VIEWED',
    'RESPONDED'
);


ALTER TYPE public."MentionStatus" OWNER TO moka;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."NotificationType" AS ENUM (
    'INTERVIEW_REMINDER',
    'FEEDBACK_REQUEST',
    'PROCESS_UPDATE',
    'SYSTEM'
);


ALTER TYPE public."NotificationType" OWNER TO moka;

--
-- Name: PositionStatus; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."PositionStatus" AS ENUM (
    'OPEN',
    'PAUSED',
    'CLOSED'
);


ALTER TYPE public."PositionStatus" OWNER TO moka;

--
-- Name: ProcessStatus; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."ProcessStatus" AS ENUM (
    'IN_PROGRESS',
    'WAITING_HR',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public."ProcessStatus" OWNER TO moka;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: moka
--

CREATE TYPE public."Role" AS ENUM (
    'HR',
    'INTERVIEWER'
);


ALTER TYPE public."Role" OWNER TO moka;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: InterviewEmailLog; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public."InterviewEmailLog" (
    id text NOT NULL,
    "interviewId" text NOT NULL,
    "candidateId" text NOT NULL,
    "recipientEmail" text NOT NULL,
    subject text NOT NULL,
    content text NOT NULL,
    "sentBy" text NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL,
    "errorMessage" text
);


ALTER TABLE public."InterviewEmailLog" OWNER TO moka;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO moka;

--
-- Name: ai_diagnoses; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.ai_diagnoses (
    id text NOT NULL,
    "processId" text NOT NULL,
    "roundNumber" integer NOT NULL,
    "positionId" text,
    "matchScore" integer,
    "matchLevel" text,
    strengths text[],
    weaknesses text[],
    suggestions text[],
    questions text[],
    summary text DEFAULT ''::text NOT NULL,
    "rawOutput" text DEFAULT ''::text NOT NULL,
    "inputSnapshot" jsonb,
    "analyzedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "analyzedBy" text DEFAULT 'qwen-plus'::text NOT NULL
);


ALTER TABLE public.ai_diagnoses OWNER TO moka;

--
-- Name: candidate_mentions; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.candidate_mentions (
    id text NOT NULL,
    "candidateId" text NOT NULL,
    "interviewerId" text NOT NULL,
    "mentionedById" text NOT NULL,
    message text,
    status public."MentionStatus" DEFAULT 'PENDING'::public."MentionStatus" NOT NULL,
    "viewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.candidate_mentions OWNER TO moka;

--
-- Name: candidate_status_history; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.candidate_status_history (
    id text NOT NULL,
    "candidateId" text NOT NULL,
    "oldStatus" public."CandidateStatus",
    "newStatus" public."CandidateStatus" NOT NULL,
    reason text,
    "changedBy" text,
    "relatedInterviewId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.candidate_status_history OWNER TO moka;

--
-- Name: candidates; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.candidates (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    "positionId" text,
    status public."CandidateStatus" DEFAULT 'PENDING'::public."CandidateStatus" NOT NULL,
    source public."CandidateSource",
    "resumeUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.candidates OWNER TO moka;

--
-- Name: feedback_tokens; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.feedback_tokens (
    id text NOT NULL,
    "interviewId" text NOT NULL,
    "interviewerId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "isUsed" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.feedback_tokens OWNER TO moka;

--
-- Name: interview_feedbacks; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.interview_feedbacks (
    id text NOT NULL,
    "interviewId" text NOT NULL,
    "interviewerId" text NOT NULL,
    result public."FeedbackResult" NOT NULL,
    strengths text,
    weaknesses text,
    "overallRating" integer,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.interview_feedbacks OWNER TO moka;

--
-- Name: interview_processes; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.interview_processes (
    id text NOT NULL,
    "candidateId" text NOT NULL,
    "positionId" text NOT NULL,
    "currentRound" integer DEFAULT 1 NOT NULL,
    "totalRounds" integer DEFAULT 3 NOT NULL,
    status public."ProcessStatus" DEFAULT 'IN_PROGRESS'::public."ProcessStatus" NOT NULL,
    "hasHRRound" boolean DEFAULT true NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.interview_processes OWNER TO moka;

--
-- Name: interview_rounds; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.interview_rounds (
    id text NOT NULL,
    "processId" text NOT NULL,
    "roundNumber" integer NOT NULL,
    "interviewerId" text NOT NULL,
    "isHRRound" boolean DEFAULT false NOT NULL,
    "roundType" text NOT NULL
);


ALTER TABLE public.interview_rounds OWNER TO moka;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.interviews (
    id text NOT NULL,
    "candidateId" text NOT NULL,
    "positionId" text NOT NULL,
    "interviewerId" text NOT NULL,
    type public."InterviewType" NOT NULL,
    format public."InterviewFormat" NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    location text,
    "meetingUrl" text,
    "meetingNumber" text,
    status public."InterviewStatus" DEFAULT 'SCHEDULED'::public."InterviewStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdById" text,
    "isHRRound" boolean DEFAULT false NOT NULL,
    "processId" text,
    "roundNumber" integer,
    "feishuEventId" text
);


ALTER TABLE public.interviews OWNER TO moka;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    link text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO moka;

--
-- Name: positions; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.positions (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    requirements text,
    "salaryMin" integer,
    "salaryMax" integer,
    headcount integer DEFAULT 1 NOT NULL,
    "hiredCount" integer DEFAULT 0 NOT NULL,
    "inProgressCount" integer DEFAULT 0 NOT NULL,
    status public."PositionStatus" DEFAULT 'OPEN'::public."PositionStatus" NOT NULL,
    location text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.positions OWNER TO moka;

--
-- Name: resume_files; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.resume_files (
    id text NOT NULL,
    "candidateId" text NOT NULL,
    "fileName" text NOT NULL,
    "fileType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "filePath" text NOT NULL,
    "fileUrl" text NOT NULL,
    "uploadedBy" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resume_files OWNER TO moka;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO moka;

--
-- Name: users; Type: TABLE; Schema: public; Owner: moka
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    email text,
    role public."Role" DEFAULT 'INTERVIEWER'::public."Role" NOT NULL,
    "avatarUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "feishuOuId" text
);


ALTER TABLE public.users OWNER TO moka;

--
-- Data for Name: InterviewEmailLog; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public."InterviewEmailLog" (id, "interviewId", "candidateId", "recipientEmail", subject, content, "sentBy", "sentAt", status, "errorMessage") FROM stdin;
204005e6-39bc-4a8a-be57-f65706b252bc	13443001-a6ce-4ac2-bf30-34b73cc4aa2a	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	liuyongneng1015@126.com	面试通知 - AI智能体架构师	<p>尊敬的 <strong>刘永能</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI智能体架构师</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI智能体架构师</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年4月15日 2026年4月15日 10:00 - 11:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：351-322-626">#腾讯会议：351-322-626</a></p><p>\n</p><p><strong>面试官：</strong>肖仕杰</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-04-14 09:40:42.657	sent	\N
7f9ddaed-1965-429e-b0b8-cbc97d447133	eeac9dba-ec41-4463-9fa4-c49f9a46984f	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	liuyongneng1015@126.com	面试通知 - AI智能体架构师	<p>尊敬的 <strong>刘永能</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI智能体架构师</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI智能体架构师</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年4月16日 2026年4月16日 11:00 - 12:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：429-760-917">#腾讯会议：429-760-917</a></p><p>\n</p><p><strong>面试官：</strong>吴素敏</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-04-15 05:45:56.926	sent	\N
f0f0ae4f-ff96-4e01-9942-5f546a60664b	5a764356-c773-4e8d-81b3-aea6b1d0d591	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	iamjasmine100005@gmail.com	面试通知 - 高级销售经理	<p>尊敬的 <strong>萧晓霞</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>高级销售经理</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>高级销售经理</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年4月22日 11:00 - 12:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：318-844-638">#腾讯会议：318-844-638</a></p><p>\n</p><p><strong>面试官：</strong>吴素敏</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-04-21 09:44:56.831	sent	\N
a258870f-03f5-4e09-b113-81b0c0c6c97b	c2ef7161-88fd-4759-88a4-f0c69375d6ae	b596dd09-d74b-4946-9ef1-cd447332984d	huang_9464@sina.com	面试通知 - AI+教育智能硬件 软件产品经理	<p>尊敬的 <strong>吴瑞煌</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI+教育智能硬件 软件产品经理</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI+教育智能硬件 软件产品经理</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年4月29日 2026年4月29日 18:00 - 19:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="腾讯会议：737-916-349">腾讯会议：737-916-349</a></p><p>\n</p><p><strong>面试官：</strong>赵从志</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-04-29 08:50:27.611	sent	\N
8a074070-6b44-42de-9b49-7de94b8bd58e	e58e5ff9-ac5e-49eb-b0b8-f28ede8e108d	b596dd09-d74b-4946-9ef1-cd447332984d	huang_9464@sina.com	面试通知 - AI+教育智能硬件 软件产品经理	<p>尊敬的 <strong>吴瑞煌</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI+教育智能硬件 软件产品经理</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI+教育智能硬件 软件产品经理</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月9日 14:00 - 15:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：723-730-960">#腾讯会议：723-730-960</a></p><p>\n</p><p><strong>面试官：</strong>吴素敏</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-06 06:40:12.149	sent	\N
7d46b801-1794-4ebe-bcb9-77b8dd295eb2	c4e49c75-3834-42ac-92cb-70fed0f8d10e	77a3b50c-dc9a-4927-822f-2bd9e306d489	2235913209@qq.com	面试通知 - AI智能体架构师	<p>尊敬的 <strong>陈世健</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI智能体架构师</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI智能体架构师</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月8日 14:00 - 15:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：391-596-187">#腾讯会议：391-596-187</a></p><p>\n</p><p><strong>面试官：</strong>肖仕杰</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-07 06:15:14.538	sent	\N
e34c586e-226b-41dc-b2ea-71d0ea5fe29a	f1d0b211-8a51-4815-a7ac-7d5e561b19cc	cc902c14-ccfa-47ad-83ae-ad03563001ac	2273535760@qq.com	面试通知 - AI智能体架构师	<p>尊敬的 <strong>欧阳凌</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI智能体架构师</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI智能体架构师</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月8日 15:00 - 16:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：520-789-807">#腾讯会议：520-789-807</a></p><p>\n</p><p><strong>面试官：</strong>肖仕杰</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-07 06:26:48.918	sent	\N
70bdddde-ada7-4af4-8b77-4660439965fe	04bb214e-3726-44c5-b1f8-653522bcb4e9	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	1242422890@qq.com	面试通知 - 生产仓储专员	<p>尊敬的 <strong>罗健维</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>生产仓储专员</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>生产仓储专员</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月11日 14:00 - 15:00</span></p><p>\n</p><p><strong>形式：</strong>线下</p><p>\n</p><p><strong>面试地点：</strong>深圳市福田保税区长富金茂大厦1号楼5503深圳码隆智能科技有限公司</p><p>\n\n</p><p><strong>面试官：</strong>肖仕杰</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-07 08:27:05.742	sent	\N
ae3f5c4e-cb85-4e75-8c6c-f509e7406493	c1526cd0-26d9-42e0-aa3e-c9ae13e2d077	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	caizhicy@qq.com	面试通知 - AI+教育智能硬件 软件产品经理	<p>尊敬的 <strong>王彩月</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI+教育智能硬件 软件产品经理</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI+教育智能硬件 软件产品经理</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月12日 16:00 - 17:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：775-906-384">#腾讯会议：775-906-384</a></p><p>\n</p><p><strong>面试官：</strong>廖逍虓</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-11 02:19:47.308	sent	\N
b711fb12-618f-41c2-ada4-44fe5be26da5	1013a612-ad2a-4563-8a29-7be47aa9a65a	56910296-ec6c-4dac-94ad-0e7f2e8cba26	398931580@qq.com	面试通知 - AI+教育智能硬件 软件产品经理	<p>尊敬的 <strong>李猛</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>AI+教育智能硬件 软件产品经理</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>AI+教育智能硬件 软件产品经理</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月12日 15:00 - 16:00</span></p><p>\n</p><p><strong>形式：</strong>线上</p><p>\n\n</p><p><strong>会议链接：</strong><a href="#腾讯会议：105-682-977">#腾讯会议：105-682-977</a></p><p>\n</p><p><strong>面试官：</strong>廖逍虓</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-11 03:38:52.783	sent	\N
d6f98746-6cf5-4eb1-b6d1-0afe8a8cc7fa	fb48be98-698a-4676-8383-12328c26b837	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	1239079837@qq.com	面试通知 - 测试工程师	<p>尊敬的 <strong>朱建锟</strong> 您好：</p><p>\n</p><p>感谢您应聘我司 <strong>测试工程师</strong> 职位。经过初步筛选，我们诚挚邀请您参加面试：</p><p>\n</p><p><br></p><p>\n</p><h3>面试信息</h3><p>\n</p><p><strong>职位：</strong>测试工程师</p><p>\n</p><p><strong>时间：</strong><span style="color: #4371FF;">2026年5月15日 14:00 - 15:00</span></p><p>\n</p><p><strong>形式：</strong>线下</p><p>\n</p><p><strong>面试地点：</strong>深圳市福田区长富金茂大厦1号楼5503深圳码隆智能科技有限公司</p><p>\n\n</p><p><strong>面试官：</strong>肖仕杰</p><p>\n</p><p><br></p><p>\n</p><p>请您准时参加。如有任何问题，请随时与我们联系。</p><p>\n</p><p>祝您面试顺利！</p>	system	2026-05-14 03:47:08.737	sent	\N
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b09e5bb8-5c84-4cd4-b4ab-3945e9019dfa	d7dab9b75b5a7afbb549b876304b9ec302f8959f227593a2002b15842331d5c3	2026-04-09 02:18:35.73539+00	20260212094755_init	\N	\N	2026-04-09 02:18:35.667051+00	1
15bd52e5-ac49-4234-b2dd-bd75ec2140d3	532515a845aa495cc70200cca0c15cdb45c24977221a3dbc0bc1b2f40e6ca8c2	2026-04-09 02:18:35.767227+00	20260220041559_add_interview_process_tables	\N	\N	2026-04-09 02:18:35.737167+00	1
d826b25d-16ef-4d39-8a93-bfd406daba83	a5826493d4008c3f6f6977373866ee34566dde3344ed807933732b6f77c8adcf	2026-04-09 02:18:35.782781+00	20260226020542_add_notification	\N	\N	2026-04-09 02:18:35.768564+00	1
e29af695-6edb-4818-a121-58e2663c7940	eed8dd29da654fd36a3ee8334adb69357b377eec611355124a76adb05ddf489a	2026-04-09 02:18:35.902255+00	20260226030450_add_resume_mention_status_features	\N	\N	2026-04-09 02:18:35.785159+00	1
b29319a3-a9d4-435e-bad1-d6b98ae9bc23	93c77b1877c32281ddb17f205ee78973d450d4d65311ef753664927f9aa4d2f1	2026-04-09 02:18:35.91328+00	20260326080000_add_user_is_active	\N	\N	2026-04-09 02:18:35.904759+00	1
2dd0d111-06b1-41d6-977b-3232e33fcdcd	0deb43844f08e7c54808fb532fa99b1ddc84687f22de5717a5578abbb2042e7a	2026-04-09 03:18:47.697266+00	20260407_add_interview_unique_constraint	\N	\N	2026-04-09 03:18:47.565556+00	1
migration-20260409	sha256:xxx	2026-04-09 06:12:37.184521+00	20260409_add_interview_email_log		\N	2026-04-09 06:12:37.184521+00	1
\.


--
-- Data for Name: ai_diagnoses; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.ai_diagnoses (id, "processId", "roundNumber", "positionId", "matchScore", "matchLevel", strengths, weaknesses, suggestions, questions, summary, "rawOutput", "inputSnapshot", "analyzedAt", "analyzedBy") FROM stdin;
655ce7f0-e3d9-4879-9254-df5fc9cec6e0	cda3e8df-a08a-43a8-ba42-217d0bad11c4	3	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	85	high	{连续两轮获得满分评价，稳定性与专业度获高度认可,业务拓展实绩突出（个人贡献55%-60%年业绩），与高级销售经理岗位核心要求高度契合,C-level客户关系建设、跨境项目推进及多线程高管支持经验扎实}	{第2轮标注PENDING，暗示存在需进一步澄清的判断点（如战略思维深度或跨部门影响力边界）,国际项目经验提及菲律宾、肯尼亚等，但缺乏具体角色、规模、挑战及复盘细节，待验证落地能力颗粒度}	{重点考察第2轮‘PENDING’背后的具体疑虑是否已通过候选人准备得到回应,深入追问1–2个高价值项目全周期细节（尤其从线索获取、竞争应对、高层博弈到回款闭环），验证销售方法论成熟度,评估其从‘执行型销售’向‘策略型销售管理者’转型的意愿与潜力，关注人才协同与团队赋能意识}	{第2轮面试官将您的评估标记为PENDING，请结合该反馈，说明您近期在战略视角或跨职能推动力方面的关键反思与提升动作,请详细还原一个您主导签下的千万元级项目：当时最大的非价格类障碍是什么？您如何识别并系统性破局？最终如何确保交付与客户长期满意？,如果加入本团队担任高级销售经理，您计划在前90天内如何建立信任、识别关键杠杆点，并推动一项可量化的业务突破？}	候选人履历扎实、业绩硬核、语言与跨文化能力突出，两轮面试均获满分，匹配度高。本轮核心任务是穿透‘PENDING’背后的隐性评估维度，验证其战略纵深、复杂项目复盘能力及管理潜质，以确认是否具备承担更大责任的综合素养。	{"matchScore":85,"matchLevel":"high","strengths":["连续两轮获得满分评价，稳定性与专业度获高度认可","业务拓展实绩突出（个人贡献55%-60%年业绩），与高级销售经理岗位核心要求高度契合","C-level客户关系建设、跨境项目推进及多线程高管支持经验扎实"],"weaknesses":["第2轮标注PENDING，暗示存在需进一步澄清的判断点（如战略思维深度或跨部门影响力边界）","国际项目经验提及菲律宾、肯尼亚等，但缺乏具体角色、规模、挑战及复盘细节，待验证落地能力颗粒度"],"suggestions":["重点考察第2轮‘PENDING’背后的具体疑虑是否已通过候选人准备得到回应","深入追问1–2个高价值项目全周期细节（尤其从线索获取、竞争应对、高层博弈到回款闭环），验证销售方法论成熟度","评估其从‘执行型销售’向‘策略型销售管理者’转型的意愿与潜力，关注人才协同与团队赋能意识"],"questions":["第2轮面试官将您的评估标记为PENDING，请结合该反馈，说明您近期在战略视角或跨职能推动力方面的关键反思与提升动作","请详细还原一个您主导签下的千万元级项目：当时最大的非价格类障碍是什么？您如何识别并系统性破局？最终如何确保交付与客户长期满意？","如果加入本团队担任高级销售经理，您计划在前90天内如何建立信任、识别关键杠杆点，并推动一项可量化的业务突破？"],"summary":"候选人履历扎实、业绩硬核、语言与跨文化能力突出，两轮面试均获满分，匹配度高。本轮核心任务是穿透‘PENDING’背后的隐性评估维度，验证其战略纵深、复杂项目复盘能力及管理潜质，以确认是否具备承担更大责任的综合素养。"}	{"isHRRound": false, "positionId": "aeeebdcd-507b-4ac9-9f3d-96ae48745d3f", "candidateId": "15b2a0ff-f2d4-4787-9cdf-01f6f055556b", "roundNumber": 3}	2026-04-21 11:22:12.324	qwen-plus
1f3981b3-9f0c-42ee-8c59-ba3e056e207e	cda3e8df-a08a-43a8-ba42-217d0bad11c4	1	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	78	medium	{8年业务拓展与高价值项目成交经验,C-level客户关系建设与维护能力,跨境及多线程项目推进能力,强结果导向与业绩贡献记录（个人签约占公司年业绩55%-60%）,商务谈判与复杂合同落地经验}	{无智慧教育行业直接从业经历,缺乏教育招投标实操经验,专业背景为翻译而非市场营销或计算机相关,未体现对智慧实验/智慧校园等具体产品技术的理解}	{重点考察其快速学习教育行业知识及产品方案的能力,深入询问其过往跨行业转型经验（如从建筑咨询切入国际项目），评估行业迁移可行性,验证其在非教育领域中‘需求挖掘—方案匹配—资源整合—闭环交付’的完整方法论是否可复用于教育场景,了解其对教育局、学校等B2G/B2B决策链的理解及实际触达路径}	{}		{"matchScore":78,"matchLevel":"medium","strengths":["8年业务拓展与高价值项目成交经验","C-level客户关系建设与维护能力","跨境及多线程项目推进能力","强结果导向与业绩贡献记录（个人签约占公司年业绩55%-60%）","商务谈判与复杂合同落地经验"],"weaknesses":["无智慧教育行业直接从业经历","缺乏教育招投标实操经验","专业背景为翻译而非市场营销或计算机相关","未体现对智慧实验/智慧校园等具体产品技术的理解"],"suggestions":["重点考察其快速学习教育行业知识及产品方案的能力","深入询问其过往跨行业转型经验（如从建筑咨询切入国际项目），评估行业迁移可行性","验证其在非教育领域中‘需求挖掘—方案匹配—资源整合—闭环交付’的完整方法论是否可复用于教育场景","了解其对教育局、学校等B2G/B2B决策链的理解及实际触达路径"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "aeeebdcd-507b-4ac9-9f3d-96ae48745d3f", "candidateId": "15b2a0ff-f2d4-4787-9cdf-01f6f055556b", "roundNumber": 1}	2026-04-22 02:34:26.775	qwen-plus
6ca88533-0da5-4e1c-bd11-d1d31e27cf85	cda3e8df-a08a-43a8-ba42-217d0bad11c4	2	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	78	medium	{第一轮反馈中技术能力获认可,简历显示有突出的业务拓展与C-level客户成交实绩,具备国际化项目落地经验及双语商务能力}	{第一轮指出沟通表达需要提升,高管支持与销售职能融合角色的边界理解待验证,跨行业销售方法论迁移能力未充分体现}	{重点考察第一轮提到的薄弱点是否有改善,深入验证简历中的核心项目经验，特别是单体千万级合同的个人主导路径与风险应对细节,评估其从建筑咨询行业向目标行业的销售逻辑迁移能力与商业敏感度}	{针对第一轮反馈中提到的沟通表达问题，请分享一个你主动优化表达方式并带来实际业务影响的具体案例,你在简历中提到‘刷新公司历史单项目签约记录’的数千万元合同，请详细说明你在该项目中独立承担的关键决策点、遇到的最大阻力及如何突破,如果现在要将你在毕路德积累的C-level客户拓展方法，应用到我们所处的[行业名称]领域，你会优先调整哪三个维度？为什么？}	第一轮面试中候选人技术基础扎实，业绩成果显著且具备国际化视野，但沟通表达的精准性与结构化呈现仍有提升空间。本轮需重点验证其高价值项目中的独立判断力、跨行业适配潜力及团队协作中的影响力风格。	{"matchScore":78,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有突出的业务拓展与C-level客户成交实绩","具备国际化项目落地经验及双语商务能力"],"weaknesses":["第一轮指出沟通表达需要提升","高管支持与销售职能融合角色的边界理解待验证","跨行业销售方法论迁移能力未充分体现"],"suggestions":["重点考察第一轮提到的薄弱点是否有改善","深入验证简历中的核心项目经验，特别是单体千万级合同的个人主导路径与风险应对细节","评估其从建筑咨询行业向目标行业的销售逻辑迁移能力与商业敏感度"],"questions":["针对第一轮反馈中提到的沟通表达问题，请分享一个你主动优化表达方式并带来实际业务影响的具体案例","你在简历中提到‘刷新公司历史单项目签约记录’的数千万元合同，请详细说明你在该项目中独立承担的关键决策点、遇到的最大阻力及如何突破","如果现在要将你在毕路德积累的C-level客户拓展方法，应用到我们所处的[行业名称]领域，你会优先调整哪三个维度？为什么？"],"summary":"第一轮面试中候选人技术基础扎实，业绩成果显著且具备国际化视野，但沟通表达的精准性与结构化呈现仍有提升空间。本轮需重点验证其高价值项目中的独立判断力、跨行业适配潜力及团队协作中的影响力风格。"}	{"isHRRound": false, "positionId": "aeeebdcd-507b-4ac9-9f3d-96ae48745d3f", "candidateId": "15b2a0ff-f2d4-4787-9cdf-01f6f055556b", "roundNumber": 2}	2026-04-23 11:00:13.21	qwen-plus
40c02232-8514-47f7-9584-e0b2ba2a0157	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	78	medium	{第一轮反馈中技术能力获认可,简历显示有相关项目经验,具备从0到1构建AI智能体与RAG系统的完整落地经验,拥有平台化思维与复用推广成果（多产品线部署、低代码平台设计）}	{第一轮指出业务视野较窄，缺乏跨行业/跨领域AI应用经验,团队管理经验仅限4人小团队，未体现复杂组织协同或技术决策影响力,科研成果与工业实践的衔接深度未在简历中明确体现}	{重点考察业务抽象与横向扩展能力，验证其是否具备架构师所需的系统性视角,深入验证简历中‘上下文外化’‘分层工具封装’等关键技术方案的设计动机、权衡过程与效果归因,评估其在跨部门推动AI落地（如波分、FTTR等产品线）中的实际角色与影响力}	{"第一轮面试官提到你‘业务视野较窄’，请结合‘兴小秘’在不同产品线（如IPN vs 有线院）的适配过程，说明你是如何理解并应对不同业务域需求差异的？",你在‘兴小秘’中提出的‘粗选领域-精选意图’分层工具封装方法，当时是否考虑过基于LLM自动发现工具边界？最终放弃该路径的原因是什么？,当RDC任务提醒智能体的需求方（研发团队）与iCenter办公智能体的需求方（行政/PMO）对响应延迟提出冲突SLA要求时，你的技术决策逻辑和协调方式是怎样的？}	第一轮面试中候选人技术扎实、项目成果突出，已展现出优秀AI应用工程师的能力；但作为AI智能体架构师岗位，需进一步验证其业务抽象能力、复杂系统权衡决策能力及跨团队技术影响力。本轮应聚焦架构思维深度与工程落地广度的双重考察。	{"matchScore":78,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有相关项目经验","具备从0到1构建AI智能体与RAG系统的完整落地经验","拥有平台化思维与复用推广成果（多产品线部署、低代码平台设计）"],"weaknesses":["第一轮指出业务视野较窄，缺乏跨行业/跨领域AI应用经验","团队管理经验仅限4人小团队，未体现复杂组织协同或技术决策影响力","科研成果与工业实践的衔接深度未在简历中明确体现"],"suggestions":["重点考察业务抽象与横向扩展能力，验证其是否具备架构师所需的系统性视角","深入验证简历中‘上下文外化’‘分层工具封装’等关键技术方案的设计动机、权衡过程与效果归因","评估其在跨部门推动AI落地（如波分、FTTR等产品线）中的实际角色与影响力"],"questions":["第一轮面试官提到你‘业务视野较窄’，请结合‘兴小秘’在不同产品线（如IPN vs 有线院）的适配过程，说明你是如何理解并应对不同业务域需求差异的？","你在‘兴小秘’中提出的‘粗选领域-精选意图’分层工具封装方法，当时是否考虑过基于LLM自动发现工具边界？最终放弃该路径的原因是什么？","当RDC任务提醒智能体的需求方（研发团队）与iCenter办公智能体的需求方（行政/PMO）对响应延迟提出冲突SLA要求时，你的技术决策逻辑和协调方式是怎样的？"],"summary":"第一轮面试中候选人技术扎实、项目成果突出，已展现出优秀AI应用工程师的能力；但作为AI智能体架构师岗位，需进一步验证其业务抽象能力、复杂系统权衡决策能力及跨团队技术影响力。本轮应聚焦架构思维深度与工程落地广度的双重考察。"}	{"isHRRound": false, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "2c16f1b1-543c-4f5b-8e44-55d5af77966a", "roundNumber": 2}	2026-04-23 11:32:49.502	qwen-plus
23472ca3-5bed-4fb9-b8bd-6edba0c15e10	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	1	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	88	high	{3年AI/LLM全栈开发经验，深度覆盖RAG、Agent、ReAct、MCP、上下文工程、Prompt工程,2个从0到1主导落地的AI应用（兴小秘智能体平台、有线运维助手RAG系统），覆盖多产品线规模化应用,具备技术负责人经验：独立设计架构、推动跨团队复用、获公司级AI大赛一等奖2次,"AI Native实践充分：主动优化Token消耗、构建低代码智能体平台、体系化工具封装、持续迭代交互策略",扎实科研背景：顶会顶刊论文+专利，体现强学习能力与技术洞察力}	{无明确教育行业项目经验,团队管理规模未明确（当前描述为‘技术负责人/核心开发’，但未说明直接下属人数或管理幅度）,Node.js经验未在简历中体现（岗位要求Node.js/Python至少一门，候选人仅明确Python）}	{重点验证其在‘兴小秘’项目中实际承担的团队协作与任务分配职责，确认是否具备小团队管理实操经验,"深入考察其AI Native工作习惯：如日常使用哪些AI编程工具（Cursor/Claude Code等）、如何将新技术快速转化为内部实践、是否有技术分享机制",结合教育场景模拟提问：请其现场拆解一个典型教育需求（如‘自适应学情报告生成’）的技术路径，评估方案设计能力与业务抽象能力,确认其对教育领域知识的理解程度及快速学习意愿，评估行业迁移风险}	{}		{"matchScore":88,"matchLevel":"high","strengths":["3年AI/LLM全栈开发经验，深度覆盖RAG、Agent、ReAct、MCP、上下文工程、Prompt工程","2个从0到1主导落地的AI应用（兴小秘智能体平台、有线运维助手RAG系统），覆盖多产品线规模化应用","具备技术负责人经验：独立设计架构、推动跨团队复用、获公司级AI大赛一等奖2次","AI Native实践充分：主动优化Token消耗、构建低代码智能体平台、体系化工具封装、持续迭代交互策略","扎实科研背景：顶会顶刊论文+专利，体现强学习能力与技术洞察力"],"weaknesses":["无明确教育行业项目经验","团队管理规模未明确（当前描述为‘技术负责人/核心开发’，但未说明直接下属人数或管理幅度）","Node.js经验未在简历中体现（岗位要求Node.js/Python至少一门，候选人仅明确Python）"],"suggestions":["重点验证其在‘兴小秘’项目中实际承担的团队协作与任务分配职责，确认是否具备小团队管理实操经验","深入考察其AI Native工作习惯：如日常使用哪些AI编程工具（Cursor/Claude Code等）、如何将新技术快速转化为内部实践、是否有技术分享机制","结合教育场景模拟提问：请其现场拆解一个典型教育需求（如‘自适应学情报告生成’）的技术路径，评估方案设计能力与业务抽象能力","确认其对教育领域知识的理解程度及快速学习意愿，评估行业迁移风险"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "2c16f1b1-543c-4f5b-8e44-55d5af77966a", "roundNumber": 1}	2026-04-23 12:56:11.529	qwen-plus
8c15ac0e-b9b4-44bc-bad6-0aeaa2ebf763	ce94c19a-5bac-4bf3-ab74-761c917b54a4	1	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	92	high	{4年+专注AIAgent开发，主导智维助手MultiAgent体系从0到1建设,深度掌握LangChain/LangGraph/AutoGen等主流Agent框架及RAG、Multi-Agent协同、Prompt工程、AgenticRAG、语义路由等核心能力,具备完整AI工程化落地经验：模型部署（Ollama/Xinference）、可观测性（Prometheus/Grafana/Loki/Tempo）、云原生（K8s/Helm）、知识库与知识图谱构建（Graphiti/灵犀索引）,拥有技术团队协作与跨部门推动经验（对接ITSM、AIOPS、运维、开发多团队）,"高度契合‘AI Native’特质：高频使用动态Prompt、热更新、无训练路由进化、分钟级Agent组装等创新实践"}	{教育行业背景缺失,管理规模未明确（简历未说明是否正式带团队，仅体现‘主导’和‘协作’）,前端技能标注为‘基本掌握’，而教育AI产品常需强交互体验设计}	{重点验证其在教育场景的技术迁移能力（如：如何将运维领域RAG/知识图谱经验适配至教学知识库、学情分析、个性化辅导等场景）,深入考察团队管理实质经验（是否独立负责过3人以上AI开发小组？是否制定过流程规范/技术标准/质量保障体系？）,"确认其对主流教育AI需求的理解深度（如：Socratic tutoring、自动批改、学习路径规划、合规性与可解释性要求）"}	{}		{"matchScore":92,"matchLevel":"high","strengths":["4年+专注AIAgent开发，主导智维助手MultiAgent体系从0到1建设","深度掌握LangChain/LangGraph/AutoGen等主流Agent框架及RAG、Multi-Agent协同、Prompt工程、AgenticRAG、语义路由等核心能力","具备完整AI工程化落地经验：模型部署（Ollama/Xinference）、可观测性（Prometheus/Grafana/Loki/Tempo）、云原生（K8s/Helm）、知识库与知识图谱构建（Graphiti/灵犀索引）","拥有技术团队协作与跨部门推动经验（对接ITSM、AIOPS、运维、开发多团队）","高度契合‘AI Native’特质：高频使用动态Prompt、热更新、无训练路由进化、分钟级Agent组装等创新实践"],"weaknesses":["教育行业背景缺失","管理规模未明确（简历未说明是否正式带团队，仅体现‘主导’和‘协作’）","前端技能标注为‘基本掌握’，而教育AI产品常需强交互体验设计"],"suggestions":["重点验证其在教育场景的技术迁移能力（如：如何将运维领域RAG/知识图谱经验适配至教学知识库、学情分析、个性化辅导等场景）","深入考察团队管理实质经验（是否独立负责过3人以上AI开发小组？是否制定过流程规范/技术标准/质量保障体系？）","确认其对主流教育AI需求的理解深度（如：Socratic tutoring、自动批改、学习路径规划、合规性与可解释性要求）"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "77a3b50c-dc9a-4927-822f-2bd9e306d489", "roundNumber": 1}	2026-05-07 07:20:59.156	qwen-plus
8f838f3d-9762-4268-93d6-a2394f4b6a64	7d52ddab-84fa-46b1-98ab-6d3904b440cb	1	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	92	high	{"5年+AI应用开发实战经验，深度参与6个AI Agent系统从0到1落地","精通Prompt Engineering、RAG、Multi-Agent架构设计与幻觉优化",具备技术管理经验（曾带领10-20人研发团队）,"AI Native实践者：熟练使用Dify/LangChain/AutoGen/LlamaIndex等主流框架，日常深度依赖AICoding工具",教育行业适配潜力强：具备复杂业务语义理解、多轮对话建模、可解释性输出（SHAP）、流式交互优化等教育AI核心能力}	{无明确教育行业项目经历（需确认是否接触过教育场景需求）,Node.js未在简历中体现（岗位要求Python/Node.js至少一门，虽Python极强但需验证全栈协同能力）}	{重点验证其AI智能体架构设计方法论：如何权衡效果/成本/可维护性，能否抽象出教育场景通用Agent模式,"深入考察其‘AI Native’工作习惯：是否真正以AI为第一生产力工具（如用Cursor/Claude Code重构流程），而非仅调用API",询问其在天一泓昆仑AI助手等项目中如何定义和度量‘AI输出质量’，特别是面向非技术人员的教育用户时的交互策略,确认其对教育领域特有挑战的理解：如知识准确性强约束、教学逻辑可追溯、儿童/教师友好型反馈机制等}	{}		{"matchScore":92,"matchLevel":"high","strengths":["5年+AI应用开发实战经验，深度参与6个AI Agent系统从0到1落地","精通Prompt Engineering、RAG、Multi-Agent架构设计与幻觉优化","具备技术管理经验（曾带领10-20人研发团队）","AI Native实践者：熟练使用Dify/LangChain/AutoGen/LlamaIndex等主流框架，日常深度依赖AICoding工具","教育行业适配潜力强：具备复杂业务语义理解、多轮对话建模、可解释性输出（SHAP）、流式交互优化等教育AI核心能力"],"weaknesses":["无明确教育行业项目经历（需确认是否接触过教育场景需求）","Node.js未在简历中体现（岗位要求Python/Node.js至少一门，虽Python极强但需验证全栈协同能力）"],"suggestions":["重点验证其AI智能体架构设计方法论：如何权衡效果/成本/可维护性，能否抽象出教育场景通用Agent模式","深入考察其‘AI Native’工作习惯：是否真正以AI为第一生产力工具（如用Cursor/Claude Code重构流程），而非仅调用API","询问其在天一泓昆仑AI助手等项目中如何定义和度量‘AI输出质量’，特别是面向非技术人员的教育用户时的交互策略","确认其对教育领域特有挑战的理解：如知识准确性强约束、教学逻辑可追溯、儿童/教师友好型反馈机制等"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "cc902c14-ccfa-47ad-83ae-ad03563001ac", "roundNumber": 1}	2026-05-07 07:21:33.096	qwen-plus
954179cc-d0a3-4d83-a032-11f9a51f4c1f	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	1	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	92	high	{5年以上AI/LLM工程化实战经验（保险智能体、RAG、低代码+AI平台）,"从0到1主导多个AI产品落地，具备AI Native思维与技术选型能力",具备团队管理经验（10人以上研发团队，技术经理/Leader角色）,精通Python+LangChain/LangGraph/Dify等主流AI工程栈，深度实践Prompt工程、评估优化与流式交互设计,教育背景匹配（本科计算机相关专业），英语四级可支撑英文技术文档阅读}	{无教育行业背景（岗位加分项缺失）,Node.js未在简历中体现（任职要求为Node.js/Python至少一门，候选人仅明确展示Python）}	{重点验证其AI工作流设计方法论：如何将教育场景需求（如个性化辅导、学情诊断、内容生成）映射为Agent状态机或RAG增强策略,深入考察AI效果持续优化机制：如Langfuse闭环标注、badcase归因、A/B测试Prompt的实操细节,"确认其技术领导力在AI转型中的具体作用：如何推动团队接受AI Native开发范式（如Vibe Coding、Cursor+Claude辅助开发）"}	{}		{"matchScore":92,"matchLevel":"high","strengths":["5年以上AI/LLM工程化实战经验（保险智能体、RAG、低代码+AI平台）","从0到1主导多个AI产品落地，具备AI Native思维与技术选型能力","具备团队管理经验（10人以上研发团队，技术经理/Leader角色）","精通Python+LangChain/LangGraph/Dify等主流AI工程栈，深度实践Prompt工程、评估优化与流式交互设计","教育背景匹配（本科计算机相关专业），英语四级可支撑英文技术文档阅读"],"weaknesses":["无教育行业背景（岗位加分项缺失）","Node.js未在简历中体现（任职要求为Node.js/Python至少一门，候选人仅明确展示Python）"],"suggestions":["重点验证其AI工作流设计方法论：如何将教育场景需求（如个性化辅导、学情诊断、内容生成）映射为Agent状态机或RAG增强策略","深入考察AI效果持续优化机制：如Langfuse闭环标注、badcase归因、A/B测试Prompt的实操细节","确认其技术领导力在AI转型中的具体作用：如何推动团队接受AI Native开发范式（如Vibe Coding、Cursor+Claude辅助开发）"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0", "roundNumber": 1}	2026-05-07 08:06:40.395	qwen-plus
ad2e3b46-c53f-4965-831f-d18a37683e89	461e11b1-5421-48b9-adc7-95af5dc9017b	1	5c0a8176-d97e-43ac-a700-bfc9210c772b	68	medium	{具备仓储库存管理及订单处理流程理解,有设备巡检、故障排查与现场问题处理经验,熟悉数据库及系统逻辑优化，有助于WMS/ERP数据准确性保障,责任心强、执行力强、适应高强度工作环境,具备基础办公软件操作能力与学习能力}	{非物流/仓储管理相关专业，教育背景匹配度较低,无直接生产仓储或WMS/ERP系统实操经验,缺乏电子产品/智能硬件行业背景,项目经历偏重开发，仓储实操细节描述不足,未体现对FIFO等库存原则的理解与应用}	{重点考察其对仓库核心流程（收、发、存、盘）的实际认知和场景化理解,深入了解其在汽车配件商城项目中涉及的库存逻辑设计细节，评估仓储业务理解深度,询问其在码隆科技外协及艺境文化项目执行中与仓储/物流环节的协作经验,验证其Office软件熟练度及对AI工具（如Copilot、智能盘点工具）的接触与使用意愿,评估体力适应性与安全意识，结合仓库实际工作场景提问}	{}		{"matchScore":68,"matchLevel":"medium","strengths":["具备仓储库存管理及订单处理流程理解","有设备巡检、故障排查与现场问题处理经验","熟悉数据库及系统逻辑优化，有助于WMS/ERP数据准确性保障","责任心强、执行力强、适应高强度工作环境","具备基础办公软件操作能力与学习能力"],"weaknesses":["非物流/仓储管理相关专业，教育背景匹配度较低","无直接生产仓储或WMS/ERP系统实操经验","缺乏电子产品/智能硬件行业背景","项目经历偏重开发，仓储实操细节描述不足","未体现对FIFO等库存原则的理解与应用"],"suggestions":["重点考察其对仓库核心流程（收、发、存、盘）的实际认知和场景化理解","深入了解其在汽车配件商城项目中涉及的库存逻辑设计细节，评估仓储业务理解深度","询问其在码隆科技外协及艺境文化项目执行中与仓储/物流环节的协作经验","验证其Office软件熟练度及对AI工具（如Copilot、智能盘点工具）的接触与使用意愿","评估体力适应性与安全意识，结合仓库实际工作场景提问"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "5c0a8176-d97e-43ac-a700-bfc9210c772b", "candidateId": "38a5b115-d7f4-4e74-b9d4-823fa5a40ea2", "roundNumber": 1}	2026-05-07 08:21:44.845	qwen-plus
8fd85fb4-b352-43d4-b9d2-948d03227c0e	461e11b1-5421-48b9-adc7-95af5dc9017b	2	5c0a8176-d97e-43ac-a700-bfc9210c772b	72	medium	{第一轮反馈中技术能力获认可,简历显示有相关项目经验}	{第一轮指出沟通表达需要提升,某项技能深度待验证}	{重点考察第一轮提到的薄弱点是否有改善,深入验证简历中的核心项目经验,评估与团队的协作适配度}	{针对第一轮反馈中的某个问题，请详细描述你的解决思路,你在简历中提到的基于web的汽车配件在线商城项目，具体承担了哪些职责？,如果工作中遇到意见分歧，你会如何处理？}	第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。	{"matchScore":72,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有相关项目经验"],"weaknesses":["第一轮指出沟通表达需要提升","某项技能深度待验证"],"suggestions":["重点考察第一轮提到的薄弱点是否有改善","深入验证简历中的核心项目经验","评估与团队的协作适配度"],"questions":["针对第一轮反馈中的某个问题，请详细描述你的解决思路","你在简历中提到的基于web的汽车配件在线商城项目，具体承担了哪些职责？","如果工作中遇到意见分歧，你会如何处理？"],"summary":"第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。"}	{"isHRRound": false, "positionId": "5c0a8176-d97e-43ac-a700-bfc9210c772b", "candidateId": "38a5b115-d7f4-4e74-b9d4-823fa5a40ea2", "roundNumber": 2}	2026-05-07 08:22:37.364	qwen-plus
3c7cc125-5794-4fb6-ae02-6f2e02294d62	ce94c19a-5bac-4bf3-ab74-761c917b54a4	3	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	82	high	{多轮面试中技术能力一致获好评,项目经验与岗位高度匹配,"主导多个从0到1的AI Agent体系化建设，架构设计能力突出"}	{第2轮指出对高并发后端架构理解较浅,沟通表达逻辑性与结构化呈现有待加强}	{重点考察前轮提到的薄弱点是否有改善,深入验证核心项目经验和技术深度,评估与团队和文化的适配度}	{针对第2轮反馈中提到的‘对多并发后端架构了解较浅’，请结合你在智维助手V3架构演进中处理高并发资源争用的具体方案，说明你如何补足该能力短板？,你在构建Agent评测质量保障体系时，如何定义、量化并持续优化‘Agent准确率’这一指标？是否遇到过指标失真或业务反馈偏差的情况？如何归因与修正？,你如何看待AI智能体架构师在组织中的角色定位——是技术布道者、工程落地推动者，还是业务价值翻译者？请结合你在360奇富借条跨部门协同（如ITSM、运维、开发）的实际经历说明。}	前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。	{"matchScore":82,"matchLevel":"high","strengths":["多轮面试中技术能力一致获好评","项目经验与岗位高度匹配","主导多个从0到1的AI Agent体系化建设，架构设计能力突出"],"weaknesses":["第2轮指出对高并发后端架构理解较浅","沟通表达逻辑性与结构化呈现有待加强"],"suggestions":["重点考察前轮提到的薄弱点是否有改善","深入验证核心项目经验和技术深度","评估与团队和文化的适配度"],"questions":["针对第2轮反馈中提到的‘对多并发后端架构了解较浅’，请结合你在智维助手V3架构演进中处理高并发资源争用的具体方案，说明你如何补足该能力短板？","你在构建Agent评测质量保障体系时，如何定义、量化并持续优化‘Agent准确率’这一指标？是否遇到过指标失真或业务反馈偏差的情况？如何归因与修正？","你如何看待AI智能体架构师在组织中的角色定位——是技术布道者、工程落地推动者，还是业务价值翻译者？请结合你在360奇富借条跨部门协同（如ITSM、运维、开发）的实际经历说明。"],"summary":"前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。"}	{"isHRRound": false, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "77a3b50c-dc9a-4927-822f-2bd9e306d489", "roundNumber": 3}	2026-05-08 15:27:30.858	qwen-plus
2b7395ac-e20c-4441-84cd-ff5e936433ab	ce94c19a-5bac-4bf3-ab74-761c917b54a4	2	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	78	medium	{第一轮反馈中技术能力获认可,简历显示有从0到1主导Multi-Agent架构落地的完整经验,具备AIOPS场景深度实践与工程化交付能力}	{第一轮指出沟通表达需要提升，存在技术细节阐述不够结构化的问题,简历中多项前沿技术（如LangGraph、AgenticRAG、Graphiti）缺乏量化结果或技术选型对比依据，深度待验证}	{重点考察第一轮提到的薄弱点是否有改善，尤其关注其技术表达的逻辑性与听众意识,深入验证简历中的核心项目经验，特别是智维助手V1→V3演进中的架构决策依据、技术权衡与失败复盘,评估与团队的协作适配度，聚焦其在跨职能协同（如与ITSM、CMDB、SRE团队）中的角色定位与推动力}	{第一轮面试官提到你在技术表达中有时信息密度过高、缺乏上下文铺垫，请以‘灵犀索引’为例，用三句话向非AI背景的运维负责人说明它解决了什么问题、为什么不用RAGFlow原生方案、上线后如何验证效果？,你在简历中提到‘构建Graphiti知识图谱实现3+跳推理问答’，请具体说明：图谱schema设计依据、实体关系抽取是规则/LLM/NLP混合？如何解决长尾关系覆盖不足的问题？,在推进ITSMAgent与现有工单系统对接时，你遇到的最大组织阻力是什么？最终通过什么方式（技术方案/流程设计/关键人协同）达成共识并落地？}	第一轮面试中候选人技术基础扎实，项目履历高度匹配AI智能体架构师岗位，尤其在Agent工程化、RAG+KG融合、评测体系建设方面具备稀缺实战经验。但沟通表达的结构化与受众适配性仍存提升空间，第二轮需聚焦技术深度验证、决策逻辑还原及跨团队协作真实性，以判断其是否具备独立主导复杂AI架构演进的能力。	{"matchScore":78,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有从0到1主导Multi-Agent架构落地的完整经验","具备AIOPS场景深度实践与工程化交付能力"],"weaknesses":["第一轮指出沟通表达需要提升，存在技术细节阐述不够结构化的问题","简历中多项前沿技术（如LangGraph、AgenticRAG、Graphiti）缺乏量化结果或技术选型对比依据，深度待验证"],"suggestions":["重点考察第一轮提到的薄弱点是否有改善，尤其关注其技术表达的逻辑性与听众意识","深入验证简历中的核心项目经验，特别是智维助手V1→V3演进中的架构决策依据、技术权衡与失败复盘","评估与团队的协作适配度，聚焦其在跨职能协同（如与ITSM、CMDB、SRE团队）中的角色定位与推动力"],"questions":["第一轮面试官提到你在技术表达中有时信息密度过高、缺乏上下文铺垫，请以‘灵犀索引’为例，用三句话向非AI背景的运维负责人说明它解决了什么问题、为什么不用RAGFlow原生方案、上线后如何验证效果？","你在简历中提到‘构建Graphiti知识图谱实现3+跳推理问答’，请具体说明：图谱schema设计依据、实体关系抽取是规则/LLM/NLP混合？如何解决长尾关系覆盖不足的问题？","在推进ITSMAgent与现有工单系统对接时，你遇到的最大组织阻力是什么？最终通过什么方式（技术方案/流程设计/关键人协同）达成共识并落地？"],"summary":"第一轮面试中候选人技术基础扎实，项目履历高度匹配AI智能体架构师岗位，尤其在Agent工程化、RAG+KG融合、评测体系建设方面具备稀缺实战经验。但沟通表达的结构化与受众适配性仍存提升空间，第二轮需聚焦技术深度验证、决策逻辑还原及跨团队协作真实性，以判断其是否具备独立主导复杂AI架构演进的能力。"}	{"isHRRound": false, "positionId": "80304f3b-ce66-40b9-a5c0-0c4ccdb18853", "candidateId": "77a3b50c-dc9a-4927-822f-2bd9e306d489", "roundNumber": 2}	2026-05-09 07:33:09.774	qwen-plus
a4c406aa-9839-46ba-b5a4-5033042e19bf	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	1	65b53306-d103-424a-9fcb-e41cb4020166	87	high	{6年ToB+AI复合型产品经验，覆盖教育、合规、内容审核多场景,"完整主导3个0→1 AI教育/智能硬件相关项目（AI私教、漫画翻译APP、智能审核系统）",深度理解K12语言学习场景，具备‘听-学-测-练’闭环设计能力,熟练将NLP/OCR/语音评测等AI能力落地为教育功能，并量化效果（如语音评分成本降80%、翻译准确率+20%）,具备软硬协同意识：参与智能厨电APP、AI云私教硬件适配，熟悉麦克风/摄像头等传感器对AI功能的影响,高频使用AI工具并验证提效：明确提及用AI优化PRD生成、用户洞察、翻译链路设计，符合岗位新增要求,熟悉数据闭环机制：在审核系统中设计违规数据库API反哺模型训练，在SRM中构建商业洞察中心支撑策略迭代}	{"教育硬件系统级软件经验未明确体现（如Android Launcher、家长管控模块、系统设置等）",无直接K12教材体系或教学法理论应用描述，儿童发展心理学/认知科学背景未提及,SQL或数据分析工具使用未在简历中具象化（仅提‘数据洞察’，未说明工具/指标/分析动作）}	{重点验证其在AI私教项目中与硬件团队的具体协作方式（如延迟容忍度、离线模式设计、麦克风阵列选型输入等）,深入追问‘AI辅助产品工作’的实际案例：要求其现场演示如何用Copilot/Claude生成PRD初稿或用AI分析某次A/B测试行为数据,考察教育理念转化能力：请其举例说明如何将‘最近发展区’或‘刻意练习’理论融入AI口语对话产品的交互节奏设计}	{}		{"matchScore":87,"matchLevel":"high","strengths":["6年ToB+AI复合型产品经验，覆盖教育、合规、内容审核多场景","完整主导3个0→1 AI教育/智能硬件相关项目（AI私教、漫画翻译APP、智能审核系统）","深度理解K12语言学习场景，具备‘听-学-测-练’闭环设计能力","熟练将NLP/OCR/语音评测等AI能力落地为教育功能，并量化效果（如语音评分成本降80%、翻译准确率+20%）","具备软硬协同意识：参与智能厨电APP、AI云私教硬件适配，熟悉麦克风/摄像头等传感器对AI功能的影响","高频使用AI工具并验证提效：明确提及用AI优化PRD生成、用户洞察、翻译链路设计，符合岗位新增要求","熟悉数据闭环机制：在审核系统中设计违规数据库API反哺模型训练，在SRM中构建商业洞察中心支撑策略迭代"],"weaknesses":["教育硬件系统级软件经验未明确体现（如Android Launcher、家长管控模块、系统设置等）","无直接K12教材体系或教学法理论应用描述，儿童发展心理学/认知科学背景未提及","SQL或数据分析工具使用未在简历中具象化（仅提‘数据洞察’，未说明工具/指标/分析动作）"],"suggestions":["重点验证其在AI私教项目中与硬件团队的具体协作方式（如延迟容忍度、离线模式设计、麦克风阵列选型输入等）","深入追问‘AI辅助产品工作’的实际案例：要求其现场演示如何用Copilot/Claude生成PRD初稿或用AI分析某次A/B测试行为数据","考察教育理念转化能力：请其举例说明如何将‘最近发展区’或‘刻意练习’理论融入AI口语对话产品的交互节奏设计"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "65b53306-d103-424a-9fcb-e41cb4020166", "candidateId": "78ae8cf0-fe2b-4526-8dc6-1267a4d00439", "roundNumber": 1}	2026-05-11 02:12:29.969	qwen-plus
71a362ec-4916-4978-a6d3-2afa078242c5	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2	65b53306-d103-424a-9fcb-e41cb4020166	76	medium	{AI+教育产品落地经验扎实（语境通、AI私教、团子漫画翻译）,ToB系统与合规风控复合背景匹配智能硬件软件的稳定性与合规要求,第一轮反馈中技术理解与协同能力获认可}	{第一轮指出沟通表达需提升，尤其在复杂逻辑阐述时结构化不足,智能硬件端侧产品经验（如嵌入式交互、OTA、低功耗设计、硬件耦合需求管理）在简历中未体现,跨职能推动力虽强，但教育硬件场景下与ID/EE/供应链协同的具体案例缺失}	{重点考察其对教育智能硬件典型软件栈（如RTOS/Linux应用层、语音唤醒链路、离线AI模型部署、家长管控SDK集成）的理解深度,深入验证‘AI私教’项目中软硬协同细节：是否参与过麦克风阵列调优、本地ASR引擎选型、或边缘算力约束下的功能取舍决策,评估其在资源受限（如芯片算力、内存、续航）条件下平衡AI效果与用户体验的实际方法论}	{第一轮面试官提到你在阐述技术方案时逻辑链条偶有跳跃，请以‘团子漫画翻译APP在低端安卓平板上的OCR延迟优化’为例，完整复述你的问题定位、方案设计与验证过程,你在AI语言学习产品中提到‘构建听-学-测-练闭环’，如果现在要将该闭环迁移到一款面向儿童的点读笔硬件上，你会如何重新定义各环节的软件功能边界与硬件交互方式？,当算法团队坚持采用高精度大模型提升口语评分准确率，但会导致设备发热严重、续航下降40%，而硬件团队拒绝升级主控芯片——作为产品经理，你将如何推动达成共识并交付可行方案？}	候选人具备稀缺的AI+教育ToB复合经验，且在内容生成、语音评测、OCR等关键技术落地中成果明确；但教育智能硬件领域存在端侧经验空白，且首轮暴露的结构化表达短板可能影响跨职能协同效率。第二轮需聚焦‘软硬协同真实性’与‘资源约束下的产品决策力’两大核心维度进行压力验证。	{"matchScore":76,"matchLevel":"medium","strengths":["AI+教育产品落地经验扎实（语境通、AI私教、团子漫画翻译）","ToB系统与合规风控复合背景匹配智能硬件软件的稳定性与合规要求","第一轮反馈中技术理解与协同能力获认可"],"weaknesses":["第一轮指出沟通表达需提升，尤其在复杂逻辑阐述时结构化不足","智能硬件端侧产品经验（如嵌入式交互、OTA、低功耗设计、硬件耦合需求管理）在简历中未体现","跨职能推动力虽强，但教育硬件场景下与ID/EE/供应链协同的具体案例缺失"],"suggestions":["重点考察其对教育智能硬件典型软件栈（如RTOS/Linux应用层、语音唤醒链路、离线AI模型部署、家长管控SDK集成）的理解深度","深入验证‘AI私教’项目中软硬协同细节：是否参与过麦克风阵列调优、本地ASR引擎选型、或边缘算力约束下的功能取舍决策","评估其在资源受限（如芯片算力、内存、续航）条件下平衡AI效果与用户体验的实际方法论"],"questions":["第一轮面试官提到你在阐述技术方案时逻辑链条偶有跳跃，请以‘团子漫画翻译APP在低端安卓平板上的OCR延迟优化’为例，完整复述你的问题定位、方案设计与验证过程","你在AI语言学习产品中提到‘构建听-学-测-练闭环’，如果现在要将该闭环迁移到一款面向儿童的点读笔硬件上，你会如何重新定义各环节的软件功能边界与硬件交互方式？","当算法团队坚持采用高精度大模型提升口语评分准确率，但会导致设备发热严重、续航下降40%，而硬件团队拒绝升级主控芯片——作为产品经理，你将如何推动达成共识并交付可行方案？"],"summary":"候选人具备稀缺的AI+教育ToB复合经验，且在内容生成、语音评测、OCR等关键技术落地中成果明确；但教育智能硬件领域存在端侧经验空白，且首轮暴露的结构化表达短板可能影响跨职能协同效率。第二轮需聚焦‘软硬协同真实性’与‘资源约束下的产品决策力’两大核心维度进行压力验证。"}	{"isHRRound": false, "positionId": "65b53306-d103-424a-9fcb-e41cb4020166", "candidateId": "78ae8cf0-fe2b-4526-8dc6-1267a4d00439", "roundNumber": 2}	2026-05-11 02:16:17.306	qwen-plus
26feea8e-6985-4eb7-b9fa-8a514c1ac59f	77734990-16d2-4f97-9d51-fee644a737a9	1	65b53306-d103-424a-9fcb-e41cb4020166	86	high	{AI+教育交叉经验（嗨学在线教育APP产品设计+AI智能体平台教育场景落地）,AI安全与大模型应用深度实践（LLM防护、内容检测、多模态Agent矩阵）,软硬一体化产品经验（硬件选型、协议解析、嵌入式协同需求输入）,K12用户场景理解（学习路径设计、个性化推荐、教务运营系统重构）,AI工具高频使用能力（PRD生成、数据洞察、原型辅助、培训材料自动化输出）,从0到1全周期产品落地能力（5个以上AI/教育/隐私计算类0-1项目）}	{教育硬件终端（如学习机、AI词典笔、教育平板）直接经验未明确体现,儿童发展心理学/认知科学理论背景未提及,Android系统级定制（Launcher/家长管控等）无具体项目佐证}	{重点验证其在‘AI教育硬件’场景中对麦克风阵列/摄像头/屏幕等硬件参数的软件需求定义能力，例如如何将口语评测需求转化为音频采样率、降噪算法、延迟容忍度等技术指标,深入考察其在嗨学及术源万算项目中‘学习行为数据闭环’的设计逻辑：是否构建过用户错题-知识点-推荐路径-模型反馈的完整链路,要求其现场演示一次用AI工具（如Claude+SQL+Tableau）快速分析模拟学习行为日志并生成优化建议的过程，验证AI工作流真实熟练度,询问其对K12教学法（如Bloom分类法、支架式教学）的产品转化案例，评估教育理念落地能力}	{}		{"matchScore":86,"matchLevel":"high","strengths":["AI+教育交叉经验（嗨学在线教育APP产品设计+AI智能体平台教育场景落地）","AI安全与大模型应用深度实践（LLM防护、内容检测、多模态Agent矩阵）","软硬一体化产品经验（硬件选型、协议解析、嵌入式协同需求输入）","K12用户场景理解（学习路径设计、个性化推荐、教务运营系统重构）","AI工具高频使用能力（PRD生成、数据洞察、原型辅助、培训材料自动化输出）","从0到1全周期产品落地能力（5个以上AI/教育/隐私计算类0-1项目）"],"weaknesses":["教育硬件终端（如学习机、AI词典笔、教育平板）直接经验未明确体现","儿童发展心理学/认知科学理论背景未提及","Android系统级定制（Launcher/家长管控等）无具体项目佐证"],"suggestions":["重点验证其在‘AI教育硬件’场景中对麦克风阵列/摄像头/屏幕等硬件参数的软件需求定义能力，例如如何将口语评测需求转化为音频采样率、降噪算法、延迟容忍度等技术指标","深入考察其在嗨学及术源万算项目中‘学习行为数据闭环’的设计逻辑：是否构建过用户错题-知识点-推荐路径-模型反馈的完整链路","要求其现场演示一次用AI工具（如Claude+SQL+Tableau）快速分析模拟学习行为日志并生成优化建议的过程，验证AI工作流真实熟练度","询问其对K12教学法（如Bloom分类法、支架式教学）的产品转化案例，评估教育理念落地能力"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "65b53306-d103-424a-9fcb-e41cb4020166", "candidateId": "56910296-ec6c-4dac-94ad-0e7f2e8cba26", "roundNumber": 1}	2026-05-11 03:27:53.501	qwen-plus
eed9962c-2e6f-4884-84f5-e9170bbe4daa	77734990-16d2-4f97-9d51-fee644a737a9	2	65b53306-d103-424a-9fcb-e41cb4020166	72	medium	{第一轮反馈中技术能力获认可,简历显示有相关项目经验}	{第一轮指出沟通表达需要提升,某项技能深度待验证}	{重点考察第一轮提到的薄弱点是否有改善,深入验证简历中的核心项目经验,评估与团队的协作适配度}	{针对第一轮反馈中的某个问题，请详细描述你的解决思路,你在简历中提到的XX项目，具体承担了哪些职责？,如果工作中遇到意见分歧，你会如何处理？}	第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。	{"matchScore":72,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有相关项目经验"],"weaknesses":["第一轮指出沟通表达需要提升","某项技能深度待验证"],"suggestions":["重点考察第一轮提到的薄弱点是否有改善","深入验证简历中的核心项目经验","评估与团队的协作适配度"],"questions":["针对第一轮反馈中的某个问题，请详细描述你的解决思路","你在简历中提到的XX项目，具体承担了哪些职责？","如果工作中遇到意见分歧，你会如何处理？"],"summary":"第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。"}	{"isHRRound": false, "positionId": "65b53306-d103-424a-9fcb-e41cb4020166", "candidateId": "56910296-ec6c-4dac-94ad-0e7f2e8cba26", "roundNumber": 2}	2026-05-11 03:30:18.693	qwen-plus
58e57dfa-b7c4-4a3c-b785-d8395bd7bf2f	461e11b1-5421-48b9-adc7-95af5dc9017b	3	5c0a8176-d97e-43ac-a700-bfc9210c772b	78	medium	{多轮面试中技术能力一致获好评,项目经验与岗位高度匹配,外协及项目执行经历体现强执行力与现场问题处理能力}	{某轮指出沟通表达待提升,仓储系统实操经验偏项目导向，缺乏企业级WMS实际运维经验}	{重点考察前轮提到的薄弱点是否有改善,深入验证核心项目经验和技术深度,评估与团队和文化的适配度}	{针对前轮反馈中的某个问题，请分享你的最新思考,你在项目中遇到的最大技术挑战是什么，如何解决的？,你如何看待这个岗位和团队？}	前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。	{"matchScore":78,"matchLevel":"medium","strengths":["多轮面试中技术能力一致获好评","项目经验与岗位高度匹配","外协及项目执行经历体现强执行力与现场问题处理能力"],"weaknesses":["某轮指出沟通表达待提升","仓储系统实操经验偏项目导向，缺乏企业级WMS实际运维经验"],"suggestions":["重点考察前轮提到的薄弱点是否有改善","深入验证核心项目经验和技术深度","评估与团队和文化的适配度"],"questions":["针对前轮反馈中的某个问题，请分享你的最新思考","你在项目中遇到的最大技术挑战是什么，如何解决的？","你如何看待这个岗位和团队？"],"summary":"前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。"}	{"isHRRound": false, "positionId": "5c0a8176-d97e-43ac-a700-bfc9210c772b", "candidateId": "38a5b115-d7f4-4e74-b9d4-823fa5a40ea2", "roundNumber": 3}	2026-05-11 06:35:00.068	qwen-plus
d038f54c-71d3-4fbb-a8f6-4a8f7015cd4b	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	1	f80fa106-5137-477f-80d2-8fa82a3b4380	92	high	{4年全链路测试经验，覆盖AI算法、IoT硬件、SaaS云平台多领域,熟练掌握Python+FastAPI+Pytest+PO模式，具备自动化框架自研与落地能力,熟练使用Postman/Apifox/JMeter/Charles/Fiddler等接口及抓包工具,熟悉Linux环境部署与日志分析、MySQL多表查询验证数据一致性,深度应用Cursor等AI编程工具提升测试脚本与用例生成效率,具备Docker容器化部署及Jenkins持续集成实践经验,主导多个商业项目从需求评审到产线验收的全流程质量保障}	{简历中未明确提及Jira/禅道等缺陷管理工具的实际使用细节,教育背景为本科但未体现计算机相关课程或技术认证,工作经历时间存在逻辑疑点（如2024.12-2026.03为未来时间段，疑似笔误）}	{重点核实工作时间线的真实性（如2024.12起始时间），确认当前在职状态与离职原因,深入考察其在CI/CD流程中的具体角色：是否参与测试左移实践、如何协同开发推进单元测试/契约测试,要求现场演示其自研的轻量级算法测试平台核心功能（如参数配置、结果可视化逻辑）,询问其在CV算法评测中对Precision/Recall/F1等指标的实际分析方法与优化闭环案例}	{}		{"matchScore":92,"matchLevel":"high","strengths":["4年全链路测试经验，覆盖AI算法、IoT硬件、SaaS云平台多领域","熟练掌握Python+FastAPI+Pytest+PO模式，具备自动化框架自研与落地能力","熟练使用Postman/Apifox/JMeter/Charles/Fiddler等接口及抓包工具","熟悉Linux环境部署与日志分析、MySQL多表查询验证数据一致性","深度应用Cursor等AI编程工具提升测试脚本与用例生成效率","具备Docker容器化部署及Jenkins持续集成实践经验","主导多个商业项目从需求评审到产线验收的全流程质量保障"],"weaknesses":["简历中未明确提及Jira/禅道等缺陷管理工具的实际使用细节","教育背景为本科但未体现计算机相关课程或技术认证","工作经历时间存在逻辑疑点（如2024.12-2026.03为未来时间段，疑似笔误）"],"suggestions":["重点核实工作时间线的真实性（如2024.12起始时间），确认当前在职状态与离职原因","深入考察其在CI/CD流程中的具体角色：是否参与测试左移实践、如何协同开发推进单元测试/契约测试","要求现场演示其自研的轻量级算法测试平台核心功能（如参数配置、结果可视化逻辑）","询问其在CV算法评测中对Precision/Recall/F1等指标的实际分析方法与优化闭环案例"],"questions":[],"summary":""}	{"isHRRound": true, "positionId": "f80fa106-5137-477f-80d2-8fa82a3b4380", "candidateId": "9dd8d3bf-8ab8-4203-b654-95ac35bb64ee", "roundNumber": 1}	2026-05-14 03:03:00.611	qwen-plus
b566be66-6cd0-48ae-9e9b-5a289a0734ae	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2	f80fa106-5137-477f-80d2-8fa82a3b4380	72	medium	{第一轮反馈中技术能力获认可,简历显示有相关项目经验}	{第一轮指出沟通表达需要提升,某项技能深度待验证}	{重点考察第一轮提到的薄弱点是否有改善,深入验证简历中的核心项目经验,评估与团队的协作适配度}	{针对第一轮反馈中的某个问题，请详细描述你的解决思路,"你在简历中提到的正大集团Cpaxtra SaaS云平台及AI算法集群项目，具体承担了哪些职责？",如果工作中遇到意见分歧，你会如何处理？}	第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。	{"matchScore":72,"matchLevel":"medium","strengths":["第一轮反馈中技术能力获认可","简历显示有相关项目经验"],"weaknesses":["第一轮指出沟通表达需要提升","某项技能深度待验证"],"suggestions":["重点考察第一轮提到的薄弱点是否有改善","深入验证简历中的核心项目经验","评估与团队的协作适配度"],"questions":["针对第一轮反馈中的某个问题，请详细描述你的解决思路","你在简历中提到的正大集团Cpaxtra SaaS云平台及AI算法集群项目，具体承担了哪些职责？","如果工作中遇到意见分歧，你会如何处理？"],"summary":"第一轮面试中候选人技术基础扎实，但沟通表达有待加强。本轮需重点验证其实际项目经验和团队协作能力。"}	{"isHRRound": false, "positionId": "f80fa106-5137-477f-80d2-8fa82a3b4380", "candidateId": "9dd8d3bf-8ab8-4203-b654-95ac35bb64ee", "roundNumber": 2}	2026-05-14 03:03:56.648	qwen-plus
d5253b59-09c9-45ea-8a5c-20e93cfe8b7b	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	3	f80fa106-5137-477f-80d2-8fa82a3b4380	82	high	{多轮面试中技术能力一致获好评,项目经验与岗位高度匹配,具备测试开发复合能力及商业落地成果}	{某轮指出沟通表达待提升,算法评测深度与工程化抽象能力需进一步验证}	{重点考察前轮提到的薄弱点是否有改善,深入验证核心项目经验和技术深度,评估与团队和文化的适配度}	{针对前轮反馈中的沟通表达问题，请分享一个你近期主动优化跨团队协作方式的具体案例,你在正大集团偷盗检测算法测试中推动召回率从30%提升至60%，请详细说明你是如何定位瓶颈、设计专项测试集并协同算法团队闭环的？,你如何看待本岗位在AI+IoT交叉领域的角色定位？如果加入，你希望在3个月内为团队带来什么可衡量的价值？}	前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。	{"matchScore":82,"matchLevel":"high","strengths":["多轮面试中技术能力一致获好评","项目经验与岗位高度匹配","具备测试开发复合能力及商业落地成果"],"weaknesses":["某轮指出沟通表达待提升","算法评测深度与工程化抽象能力需进一步验证"],"suggestions":["重点考察前轮提到的薄弱点是否有改善","深入验证核心项目经验和技术深度","评估与团队和文化的适配度"],"questions":["针对前轮反馈中的沟通表达问题，请分享一个你近期主动优化跨团队协作方式的具体案例","你在正大集团偷盗检测算法测试中推动召回率从30%提升至60%，请详细说明你是如何定位瓶颈、设计专项测试集并协同算法团队闭环的？","你如何看待本岗位在AI+IoT交叉领域的角色定位？如果加入，你希望在3个月内为团队带来什么可衡量的价值？"],"summary":"前几轮面试中候选人表现稳定，技术能力扎实。本轮需进一步验证其综合能力和长期发展潜力。"}	{"isHRRound": false, "positionId": "f80fa106-5137-477f-80d2-8fa82a3b4380", "candidateId": "9dd8d3bf-8ab8-4203-b654-95ac35bb64ee", "roundNumber": 3}	2026-05-14 03:36:08.319	qwen-plus
\.


--
-- Data for Name: candidate_mentions; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.candidate_mentions (id, "candidateId", "interviewerId", "mentionedById", message, status, "viewedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: candidate_status_history; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.candidate_status_history (id, "candidateId", "oldStatus", "newStatus", reason, "changedBy", "relatedInterviewId", "createdAt") FROM stdin;
a1fd0d2d-a5dd-4a91-bf90-4e4846a52415	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	b90a3c05-8ab8-453f-9850-f3768cdade2b	cde257fa-6763-4b96-96bd-dbee544266b8	2026-04-14 09:19:32.942
1f13a8a0-73ce-4dae-9db0-f68aa830c7cf	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	b90a3c05-8ab8-453f-9850-f3768cdade2b	13443001-a6ce-4ac2-bf30-34b73cc4aa2a	2026-04-14 09:31:36.988
cecddcf0-ab4a-49b7-8514-d2e02bd3b5c3	2c16f1b1-543c-4f5b-8e44-55d5af77966a	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	b90a3c05-8ab8-453f-9850-f3768cdade2b	e7b2997c-97c7-4dbd-b751-c3660ac543b1	2026-04-14 09:44:33.838
1349c3ef-d6fd-4dce-bbdc-8466b1a0c544	2c16f1b1-543c-4f5b-8e44-55d5af77966a	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	b90a3c05-8ab8-453f-9850-f3768cdade2b	4fa94d00-ae24-4db9-ba46-e3dd71d0dd80	2026-04-14 10:00:39.004
c9e87056-2a57-4524-9a61-089e22701ea4	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	f3cb77df-3ccb-404b-942d-52d894e66325	2026-04-21 09:37:17.165
39259562-12a9-40f7-a262-8c6a9bf11343	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	0060817a-b7e9-45b9-924d-0369767de4a5	2026-04-21 09:42:53.543
fdb4c2c8-0f17-4ae5-aa37-cda713c95fdc	b596dd09-d74b-4946-9ef1-cd447332984d	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	e245030a-f291-49b0-acde-45a5d204f596	2026-04-29 08:44:53.053
48457bbb-733d-43ae-aa8f-bd468f410ae9	b596dd09-d74b-4946-9ef1-cd447332984d	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	c2ef7161-88fd-4759-88a4-f0c69375d6ae	2026-04-29 08:46:14.134
03835e25-3c5c-445d-882d-43505ad4f020	77a3b50c-dc9a-4927-822f-2bd9e306d489	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	e6ee07fc-bbe9-407a-835e-d8c9eea0edde	2026-05-07 06:09:40.765
565f7179-a9b3-4feb-ac1b-abb84748296f	77a3b50c-dc9a-4927-822f-2bd9e306d489	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	c4e49c75-3834-42ac-92cb-70fed0f8d10e	2026-05-07 06:14:52.886
c8b9512d-2275-4818-acab-dfcc081ea685	cc902c14-ccfa-47ad-83ae-ad03563001ac	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	b6ff9457-2dab-4494-896d-64b226911a24	2026-05-07 06:16:34.146
c4bbd871-e253-4cb5-afb8-79f0b08679be	cc902c14-ccfa-47ad-83ae-ad03563001ac	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	f1d0b211-8a51-4815-a7ac-7d5e561b19cc	2026-05-07 06:23:38.761
18375207-8695-4f52-a32b-8f67d9c34a76	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	08f7256e-541f-4219-8ed0-fb195c44b1c3	2026-05-07 08:21:48.321
071ea044-eb8c-4423-b840-31ad7e9f0c23	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	04bb214e-3726-44c5-b1f8-653522bcb4e9	2026-05-07 08:24:00.614
0f3e883f-145f-4140-a0d0-d861c15fe9b8	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	49cb5e40-45e2-4686-a8ce-c10c16e21de9	2026-05-11 02:14:03.612
fa19db45-6b70-4648-bda6-875cad9798ef	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	c1526cd0-26d9-42e0-aa3e-c9ae13e2d077	2026-05-11 02:16:03.835
5af5a4a8-530e-47eb-af8f-24d4f2e59082	56910296-ec6c-4dac-94ad-0e7f2e8cba26	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	e6571e3c-e0e6-466e-abc7-2b0f17d23847	2026-05-11 03:27:43.329
3a475399-ed32-4688-ac52-55256db90f4a	56910296-ec6c-4dac-94ad-0e7f2e8cba26	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	1013a612-ad2a-4563-8a29-7be47aa9a65a	2026-05-11 03:30:13.284
ee44ec6f-cc6f-410d-a07a-aac980584464	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	PENDING	INTERVIEW_1	面试安排 - 初试（第1轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	db2e7224-875a-4756-9ad2-30328c51d2ea	2026-05-14 03:03:12.415
67f42583-2750-4806-9241-fd740e641f6d	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	INTERVIEW_1	INTERVIEW_2	面试安排 - 复试（第2轮）	4f0dd80b-c682-480a-ad58-9fbe08e547ad	1d75dc98-2412-43e3-8d65-bacf6c684a87	2026-05-14 03:03:51.136
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.candidates (id, name, phone, email, "positionId", status, source, "resumeUrl", "createdAt", "updatedAt") FROM stdin;
9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	朱建锟	18977484774	1239079837@qq.com	f80fa106-5137-477f-80d2-8fa82a3b4380	INTERVIEW_2	BOSS	/candidates/resumes/9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	2026-05-14 02:57:44.495	2026-05-14 03:03:51.134
77a3b50c-dc9a-4927-822f-2bd9e306d489	陈世健	15815127500	2235913209@qq.com	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	INTERVIEW_2	BOSS	/candidates/resumes/77a3b50c-dc9a-4927-822f-2bd9e306d489	2026-05-07 06:07:58.759	2026-05-07 06:14:52.883
2c16f1b1-543c-4f5b-8e44-55d5af77966a	曹奇	18883145918	18883145918@163.com	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	INTERVIEW_2	BOSS	/candidates/resumes/2c16f1b1-543c-4f5b-8e44-55d5af77966a	2026-04-14 02:22:46.722	2026-04-14 10:00:39.002
cc902c14-ccfa-47ad-83ae-ad03563001ac	欧阳凌	18520846021	2273535760@qq.com	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	INTERVIEW_2	BOSS	/candidates/resumes/cc902c14-ccfa-47ad-83ae-ad03563001ac	2026-05-07 06:08:20.951	2026-05-07 06:23:38.759
4d866173-d567-484f-a2fe-39cf0523dde8	肖魁	17769397503	cookui@163.com	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	PENDING	BOSS	/candidates/resumes/4d866173-d567-484f-a2fe-39cf0523dde8	2026-04-13 10:48:31.56	2026-04-21 09:20:13.048
38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	罗健维	15813885760	1242422890@qq.com	5c0a8176-d97e-43ac-a700-bfc9210c772b	INTERVIEW_2	BOSS	/candidates/resumes/38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	2026-05-07 08:20:21.568	2026-05-07 08:54:08.314
15b2a0ff-f2d4-4787-9cdf-01f6f055556b	萧晓霞	13823348409	iamjasmine100005@gmail.com	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	INTERVIEW_2	BOSS	/candidates/resumes/15b2a0ff-f2d4-4787-9cdf-01f6f055556b	2026-04-21 09:34:29.391	2026-04-21 09:42:53.541
595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	刘永能	18566756943	liuyongneng1015@126.com	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	INTERVIEW_2	BOSS	/candidates/resumes/595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	2026-04-14 02:45:29.973	2026-04-14 09:31:36.985
78ae8cf0-fe2b-4526-8dc6-1267a4d00439	王彩月	15573237240	15573237240caizhicy@qq.com	65b53306-d103-424a-9fcb-e41cb4020166	INTERVIEW_2	BOSS	/candidates/resumes/78ae8cf0-fe2b-4526-8dc6-1267a4d00439	2026-05-11 02:06:52.661	2026-05-11 02:16:03.833
b596dd09-d74b-4946-9ef1-cd447332984d	吴瑞煌	18123966098	huang_9464@sina.com	65b53306-d103-424a-9fcb-e41cb4020166	INTERVIEW_2	BOSS	/candidates/resumes/b596dd09-d74b-4946-9ef1-cd447332984d	2026-04-29 08:38:51.188	2026-04-29 08:46:14.131
56910296-ec6c-4dac-94ad-0e7f2e8cba26	李猛	17710371807	398931580@qq.com	65b53306-d103-424a-9fcb-e41cb4020166	INTERVIEW_2	BOSS	/candidates/resumes/56910296-ec6c-4dac-94ad-0e7f2e8cba26	2026-05-11 03:27:08.056	2026-05-11 03:30:13.282
\.


--
-- Data for Name: feedback_tokens; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.feedback_tokens (id, "interviewId", "interviewerId", token, "expiresAt", "usedAt", "isUsed", "createdAt") FROM stdin;
\.


--
-- Data for Name: interview_feedbacks; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.interview_feedbacks (id, "interviewId", "interviewerId", result, strengths, weaknesses, "overallRating", notes, "createdAt") FROM stdin;
afee2f97-f89a-41fb-904d-bef2b0dee998	1d75dc98-2412-43e3-8d65-bacf6c684a87	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PENDING	\N	\N	4	\N	2026-05-14 03:34:46.315
a8472a6f-3975-4571-8674-65106cdc86fa	e7b2997c-97c7-4dbd-b751-c3660ac543b1	b90a3c05-8ab8-453f-9850-f3768cdade2b	PENDING	技术扎实，学习钻研能力强，AI Native 意识较好，带4人小团队，0-1搭建兴小秘智能体、有线运维助手 RAG，服务用户多、调用量大，项目质量高，获公司级一等奖。	毕业后校招进入中兴，仅3 年工作经验，业务视野较窄。	4	\N	2026-04-14 09:56:26.527
e1884346-1332-4aa9-9b3e-dceee216ee0d	cde257fa-6763-4b96-96bd-dbee544266b8	b90a3c05-8ab8-453f-9850-f3768cdade2b	PASS	大厂背景，有带10人以上团队管理经验， 有0 到 1 主导保险智能体 Agent、RAG 知识库等项目方面落地经验。	从 Java 架构切入 AI 体系，候选人自述对大模型、微调方面经验沉淀略欠缺。	4		2026-04-14 09:29:49.812
4bcd4b1e-0d8e-4d29-9e6d-6d8a91fa84df	13443001-a6ce-4ac2-bf30-34b73cc4aa2a	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PASS	简历描述真实，后端技术和架构能力较强。\n实际的开发经验充足。\n有实际大规模用户量的AI agent架构和优化经验。	vibecoding属于平衡型使用\n对业务场景的理解一般	3	\N	2026-04-15 03:04:32.619
63e52298-0608-4aa1-bb1b-929a0394778f	f3cb77df-3ccb-404b-942d-52d894e66325	43a36a18-6230-4a1c-8e78-58b0c92ce415	PASS	\N	\N	5	\N	2026-04-21 09:42:08.002
b5d65418-4001-44f8-a33e-c6a0b7b9234e	0060817a-b7e9-45b9-924d-0369767de4a5	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PASS	\N	\N	5	\N	2026-04-21 09:43:13.698
aaacd104-0a51-4fef-9974-abdb7fece944	e245030a-f291-49b0-acde-45a5d204f596	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PASS	\N	\N	4	\N	2026-04-29 08:45:18.205
316d71ec-aa85-4766-83c0-d8a86888e40d	c2ef7161-88fd-4759-88a4-f0c69375d6ae	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PASS	\N	\N	4	\N	2026-05-06 06:35:44.96
dbf4031e-694a-428f-9d86-3dba16743bc9	e6ee07fc-bbe9-407a-835e-d8c9eea0edde	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PASS	\N	\N	4	\N	2026-05-07 06:10:04.885
5a4f5805-1d1a-47d6-b1af-a4656ef3ab6f	b6ff9457-2dab-4494-896d-64b226911a24	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PENDING	\N	\N	4	\N	2026-05-07 06:16:52.124
f058d326-be0d-4d84-853b-b88153849fa3	08f7256e-541f-4219-8ed0-fb195c44b1c3	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PASS	\N	\N	4	\N	2026-05-07 08:22:29.742
e26a3b09-f0b6-47b4-8134-81ada71f9b86	f1d0b211-8a51-4815-a7ac-7d5e561b19cc	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PASS	简历经历属实。目前在技术leader岗位，对AI agent架构、后端架构技术有较深入的理解。对教育场景agent的架构设计回答到位，思考较周全。	说话较慢，稍微缺乏激情。\n对我们岗位的工作职能了解较浅	3	\N	2026-05-08 15:25:33.958
6bd72663-f499-446e-bff0-9f38d4e4876e	c4e49c75-3834-42ac-92cb-70fed0f8d10e	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PASS	简历经验属实，有激情。	从事维护类开发，对多并发的后端架构了解较浅。\n期望较高。经验只适合于AI智能体开发工程师，不够架构级别。	3		2026-05-08 15:27:17.037
0cc9030f-02a6-4b6c-ad2d-75cec5378ac2	49cb5e40-45e2-4686-a8ce-c10c16e21de9	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PENDING	\N	\N	4	\N	2026-05-11 02:14:30.821
fee12f96-9c0b-4bff-9428-51803433fc11	e6571e3c-e0e6-466e-abc7-2b0f17d23847	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PENDING	\N	\N	4	\N	2026-05-11 03:28:21.089
8590f4f7-211e-4c1c-a635-1af0d0e3c1fd	04bb214e-3726-44c5-b1f8-653522bcb4e9	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PASS	个人对岗位的意向较强，从事过外协工作，匹配。\n计科专业毕业，有一定的潜力。	\N	4	\N	2026-05-11 06:34:52.11
12a149a8-0294-4aac-8211-5311dcd5e557	db2e7224-875a-4756-9ad2-30328c51d2ea	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PENDING	\N	\N	4	\N	2026-05-14 03:03:31.857
\.


--
-- Data for Name: interview_processes; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.interview_processes (id, "candidateId", "positionId", "currentRound", "totalRounds", status, "hasHRRound", "createdById", "createdAt", "completedAt") FROM stdin;
cda3e8df-a08a-43a8-ba42-217d0bad11c4	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	3	4	IN_PROGRESS	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-04-21 09:36:55.806	\N
2db10b9f-fc8d-48cd-b99c-9414a5c2770d	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	f80fa106-5137-477f-80d2-8fa82a3b4380	3	5	IN_PROGRESS	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-14 03:02:49.445	\N
d1cb5ab0-97ae-4756-902c-0e784762a52f	b596dd09-d74b-4946-9ef1-cd447332984d	65b53306-d103-424a-9fcb-e41cb4020166	3	4	IN_PROGRESS	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-04-29 08:44:39.741	\N
33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2c16f1b1-543c-4f5b-8e44-55d5af77966a	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	2	4	IN_PROGRESS	t	b90a3c05-8ab8-453f-9850-f3768cdade2b	2026-04-14 09:43:24.602	\N
120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	3	4	IN_PROGRESS	t	b90a3c05-8ab8-453f-9850-f3768cdade2b	2026-04-14 09:19:00.875	\N
ce94c19a-5bac-4bf3-ab74-761c917b54a4	77a3b50c-dc9a-4927-822f-2bd9e306d489	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	2	4	WAITING_HR	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-07 06:09:16.386	\N
7d52ddab-84fa-46b1-98ab-6d3904b440cb	cc902c14-ccfa-47ad-83ae-ad03563001ac	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	2	4	WAITING_HR	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-07 06:16:15.327	\N
640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	65b53306-d103-424a-9fcb-e41cb4020166	2	4	IN_PROGRESS	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-11 02:12:16.29	\N
77734990-16d2-4f97-9d51-fee644a737a9	56910296-ec6c-4dac-94ad-0e7f2e8cba26	65b53306-d103-424a-9fcb-e41cb4020166	2	4	IN_PROGRESS	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-11 03:27:33.959	\N
461e11b1-5421-48b9-adc7-95af5dc9017b	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	5c0a8176-d97e-43ac-a700-bfc9210c772b	2	4	WAITING_HR	t	4f0dd80b-c682-480a-ad58-9fbe08e547ad	2026-05-07 08:21:37.548	\N
\.


--
-- Data for Name: interview_rounds; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.interview_rounds (id, "processId", "roundNumber", "interviewerId", "isHRRound", "roundType") FROM stdin;
3ba1fbfb-4f8e-43aa-b0e6-882120a0a4c5	ce94c19a-5bac-4bf3-ab74-761c917b54a4	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
38e76c99-c3f0-4849-b2fe-58cb5728b838	ce94c19a-5bac-4bf3-ab74-761c917b54a4	2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
8f9ccff9-61d6-456f-970d-3deb31cff561	ce94c19a-5bac-4bf3-ab74-761c917b54a4	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
6e244702-fdf3-473e-b599-d8543fc7662b	ce94c19a-5bac-4bf3-ab74-761c917b54a4	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
3a261188-4afc-47ea-bfec-9193ec33e8f8	7d52ddab-84fa-46b1-98ab-6d3904b440cb	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
2f6c7bde-21f6-49c7-b73b-e872c55f0a51	7d52ddab-84fa-46b1-98ab-6d3904b440cb	2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
fa3fdffe-c993-402b-a746-2e2d352765a0	7d52ddab-84fa-46b1-98ab-6d3904b440cb	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
c4443547-93e7-4f08-b22e-18e8687a9d92	7d52ddab-84fa-46b1-98ab-6d3904b440cb	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
3d67d7a9-eaa7-4cdf-9ccd-cd45fc8e62cc	461e11b1-5421-48b9-adc7-95af5dc9017b	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
0cba8a55-d71b-41a6-bb17-65fc41b5e2f9	461e11b1-5421-48b9-adc7-95af5dc9017b	2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
cc0d502f-fc93-43f6-bbe5-29d1f6594b47	461e11b1-5421-48b9-adc7-95af5dc9017b	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
a4644b9d-1aa7-490d-b0a5-7c9f96130c0f	461e11b1-5421-48b9-adc7-95af5dc9017b	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
e4ac9518-a063-495b-aeb3-d37066124560	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
984f6f85-7d80-451a-b6c5-e94955c2db8c	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	f	TECHNICAL
064ef25a-08df-4f9d-92af-c90ba3b3d1ff	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
778c5fd8-a51e-43d5-961d-4b179d3987bd	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
f84bbfc7-f673-4c15-91f5-48879aef092f	77734990-16d2-4f97-9d51-fee644a737a9	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
896c7a0d-ec08-4fdc-80c7-06bdcbbfaa04	77734990-16d2-4f97-9d51-fee644a737a9	2	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	f	TECHNICAL
988525db-d00b-4b1b-a948-9104a7a130eb	77734990-16d2-4f97-9d51-fee644a737a9	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
6e2a8bf2-b4f9-4c31-8c20-01e5f5b16944	77734990-16d2-4f97-9d51-fee644a737a9	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
0402e0ec-07b8-43d6-959c-5a3fa21c7231	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
e92f9266-ea26-41f2-a6f8-d8b05fb032d6	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2	3501d446-de5e-4ef2-bb06-e4820f5dc3d8	f	TECHNICAL
9eaf22c5-dc54-44a6-807e-0a75c2e05863	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	3	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
c489b38e-7ae3-449e-9b06-d0b9883eae70	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	4	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
9b7bb4db-622b-4027-9b1b-86090790fd6e	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	5	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
91c885da-fd08-4f6e-8655-b8e9019cb7e6	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
76fbd725-c56c-47c0-8b1b-08221294f570	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
3521b038-ce31-411c-82e4-4d4fd5d79b2b	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
a116474b-d156-4a67-9137-3369ce8ef26b	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
c801dc86-e12c-428b-b9a4-6b8b36027d81	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
0898269f-e413-44e2-be11-c363d235e01c	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	f	TECHNICAL
cc34a6e0-f076-459c-9f5f-0de77904bae1	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
b20f8a06-f269-41a0-9069-a8549f99a72c	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
cf339b8c-a735-4da5-a55a-08276a1c66d7	cda3e8df-a08a-43a8-ba42-217d0bad11c4	1	43a36a18-6230-4a1c-8e78-58b0c92ce415	t	HR_SCREENING
43b6c2e5-c646-4515-8bb2-21f22e832502	cda3e8df-a08a-43a8-ba42-217d0bad11c4	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
e0ea29f3-7d9b-4a3f-a05e-7a144cba76b8	cda3e8df-a08a-43a8-ba42-217d0bad11c4	2	9b1b4243-193c-47da-850c-1ca74f86a27f	f	TECHNICAL
a3dd7830-7e92-49ea-97b6-b62394475102	cda3e8df-a08a-43a8-ba42-217d0bad11c4	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
1727aa9a-9c0c-428d-a756-2c027b8b4500	d1cb5ab0-97ae-4756-902c-0e784762a52f	1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	HR_SCREENING
1445ae0f-9b28-4e44-b521-38e78ec46a52	d1cb5ab0-97ae-4756-902c-0e784762a52f	2	5720b05a-36d2-4160-906e-f3212a29d1a6	f	TECHNICAL
1e3593ad-7374-47f6-ad62-bf7fd8a3919f	d1cb5ab0-97ae-4756-902c-0e784762a52f	3	77bfd979-145a-45b2-b874-a63627cabce1	f	TECHNICAL
c0ef5bff-7261-4fbe-afae-bcc7447c4367	d1cb5ab0-97ae-4756-902c-0e784762a52f	4	e0d59683-73d7-4306-a967-d023994d533e	f	FINAL
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.interviews (id, "candidateId", "positionId", "interviewerId", type, format, "startTime", "endTime", location, "meetingUrl", "meetingNumber", status, "createdAt", "createdById", "isHRRound", "processId", "roundNumber", "feishuEventId") FROM stdin;
e245030a-f291-49b0-acde-45a5d204f596	b596dd09-d74b-4946-9ef1-cd447332984d	65b53306-d103-424a-9fcb-e41cb4020166	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-04-29 08:44:00	2026-04-29 08:44:00				COMPLETED	2026-04-29 08:44:53.042	\N	t	d1cb5ab0-97ae-4756-902c-0e784762a52f	1	\N
f3cb77df-3ccb-404b-942d-52d894e66325	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	43a36a18-6230-4a1c-8e78-58b0c92ce415	INTERVIEW_1	ONLINE	2026-04-21 08:00:00	2026-04-21 09:00:00				COMPLETED	2026-04-21 09:37:17.156	\N	t	cda3e8df-a08a-43a8-ba42-217d0bad11c4	1	c5f1f338-0b7d-4ab3-abd6-5db77b04bb0d_0
e58e5ff9-ac5e-49eb-b0b8-f28ede8e108d	b596dd09-d74b-4946-9ef1-cd447332984d	65b53306-d103-424a-9fcb-e41cb4020166	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_2	ONLINE	2026-05-12 06:00:00	2026-05-12 07:00:00		https://meeting.tencent.com/dm/MY2ziIh8gPZl	#腾讯会议：229-202-464	SCHEDULED	2026-05-06 06:38:38.029	\N	f	d1cb5ab0-97ae-4756-902c-0e784762a52f	3	\N
0060817a-b7e9-45b9-924d-0369767de4a5	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	9b1b4243-193c-47da-850c-1ca74f86a27f	INTERVIEW_2	ONLINE	2026-04-21 09:34:00	2026-04-21 09:40:00				COMPLETED	2026-04-21 09:42:53.524	\N	f	cda3e8df-a08a-43a8-ba42-217d0bad11c4	2	a976c7c1-40c6-4b2e-a13d-fa9659bfdbf2_0
c2ef7161-88fd-4759-88a4-f0c69375d6ae	b596dd09-d74b-4946-9ef1-cd447332984d	65b53306-d103-424a-9fcb-e41cb4020166	5720b05a-36d2-4160-906e-f3212a29d1a6	INTERVIEW_2	ONLINE	2026-04-29 10:00:00	2026-04-29 11:00:00		腾讯会议：737-916-349		COMPLETED	2026-04-29 08:46:14.126	\N	f	d1cb5ab0-97ae-4756-902c-0e784762a52f	2	\N
5a764356-c773-4e8d-81b3-aea6b1d0d591	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_2	ONLINE	2026-04-22 03:00:00	2026-04-22 04:00:00		#腾讯会议：318-844-638		SCHEDULED	2026-04-21 09:44:02.944	\N	f	cda3e8df-a08a-43a8-ba42-217d0bad11c4	3	64e79cc4-eba1-455e-b35e-bc3b1ab700fc_0
cde257fa-6763-4b96-96bd-dbee544266b8	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-04-14 07:00:00	2026-04-14 08:00:00				COMPLETED	2026-04-14 09:19:32.928	\N	t	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	1	\N
e7b2997c-97c7-4dbd-b751-c3660ac543b1	2c16f1b1-543c-4f5b-8e44-55d5af77966a	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-04-14 08:00:00	2026-04-14 09:00:00				COMPLETED	2026-04-14 09:44:33.827	\N	t	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	1	\N
13443001-a6ce-4ac2-bf30-34b73cc4aa2a	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	ONLINE	2026-04-15 02:00:00	2026-04-15 03:00:00		#腾讯会议：351-322-626		COMPLETED	2026-04-14 09:31:36.96	\N	f	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2	\N
e6ee07fc-bbe9-407a-835e-d8c9eea0edde	77a3b50c-dc9a-4927-822f-2bd9e306d489	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-07 02:21:00	2026-05-07 03:00:00				COMPLETED	2026-05-07 06:09:40.755	\N	t	ce94c19a-5bac-4bf3-ab74-761c917b54a4	1	\N
eeac9dba-ec41-4463-9fa4-c49f9a46984f	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_2	ONLINE	2026-04-16 03:00:00	2026-04-16 04:00:00		#腾讯会议：429-760-917		SCHEDULED	2026-04-15 05:44:56.701	\N	f	120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	3	\N
eeb4a45d-a1b0-47b4-92dc-4b69a7a06c1f	2c16f1b1-543c-4f5b-8e44-55d5af77966a	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	ONLINE	2026-04-23 00:50:00	2026-04-23 13:49:00				SCHEDULED	2026-04-23 12:49:44.051	\N	f	33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2	b7b1ae48-9c5a-4796-8a87-ca1ddf5809e9_0
b6ff9457-2dab-4494-896d-64b226911a24	cc902c14-ccfa-47ad-83ae-ad03563001ac	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-07 02:30:00	2026-05-07 03:01:00				COMPLETED	2026-05-07 06:16:34.136	\N	t	7d52ddab-84fa-46b1-98ab-6d3904b440cb	1	\N
08f7256e-541f-4219-8ed0-fb195c44b1c3	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	5c0a8176-d97e-43ac-a700-bfc9210c772b	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-07 08:21:00	2026-05-07 08:21:00				COMPLETED	2026-05-07 08:21:48.305	\N	t	461e11b1-5421-48b9-adc7-95af5dc9017b	1	\N
c4e49c75-3834-42ac-92cb-70fed0f8d10e	77a3b50c-dc9a-4927-822f-2bd9e306d489	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	ONLINE	2026-05-08 06:00:00	2026-05-07 07:00:00		#腾讯会议：391-596-187		COMPLETED	2026-05-07 06:14:52.855	\N	f	ce94c19a-5bac-4bf3-ab74-761c917b54a4	2	\N
f1d0b211-8a51-4815-a7ac-7d5e561b19cc	cc902c14-ccfa-47ad-83ae-ad03563001ac	80304f3b-ce66-40b9-a5c0-0c4ccdb18853	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	ONLINE	2026-05-08 07:00:00	2026-05-08 08:00:00		#腾讯会议：520-789-807		COMPLETED	2026-05-07 06:23:38.75	\N	f	7d52ddab-84fa-46b1-98ab-6d3904b440cb	2	\N
e6571e3c-e0e6-466e-abc7-2b0f17d23847	56910296-ec6c-4dac-94ad-0e7f2e8cba26	65b53306-d103-424a-9fcb-e41cb4020166	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-11 03:27:00	2026-05-11 03:27:00				COMPLETED	2026-05-11 03:27:43.321	\N	t	77734990-16d2-4f97-9d51-fee644a737a9	1	\N
49cb5e40-45e2-4686-a8ce-c10c16e21de9	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	65b53306-d103-424a-9fcb-e41cb4020166	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-11 02:12:00	2026-05-11 02:12:00				COMPLETED	2026-05-11 02:14:03.602	\N	t	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	1	\N
c1526cd0-26d9-42e0-aa3e-c9ae13e2d077	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	65b53306-d103-424a-9fcb-e41cb4020166	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	INTERVIEW_2	ONLINE	2026-05-12 08:00:00	2026-05-12 09:00:00		#腾讯会议：775-906-384		SCHEDULED	2026-05-11 02:16:03.825	\N	f	640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2	eae7ae16-ce12-4ed6-bd42-4bbc158002c5_0
1013a612-ad2a-4563-8a29-7be47aa9a65a	56910296-ec6c-4dac-94ad-0e7f2e8cba26	65b53306-d103-424a-9fcb-e41cb4020166	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	INTERVIEW_2	ONLINE	2026-05-12 07:00:00	2026-05-12 08:00:00		#腾讯会议：105-682-977		SCHEDULED	2026-05-11 03:30:13.277	\N	f	77734990-16d2-4f97-9d51-fee644a737a9	2	0439ca25-da7f-44e2-bc6f-30f8ec78d5b7_0
04bb214e-3726-44c5-b1f8-653522bcb4e9	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	5c0a8176-d97e-43ac-a700-bfc9210c772b	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	OFFLINE	2026-05-11 06:00:00	2026-05-11 07:00:00	深圳市福田保税区长富金茂大厦1号楼5503深圳码隆智能科技有限公司			COMPLETED	2026-05-07 08:24:00.605	\N	f	461e11b1-5421-48b9-adc7-95af5dc9017b	2	\N
db2e7224-875a-4756-9ad2-30328c51d2ea	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	f80fa106-5137-477f-80d2-8fa82a3b4380	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_1	ONLINE	2026-05-04 03:02:00	2026-05-04 03:03:00				COMPLETED	2026-05-14 03:03:12.404	\N	t	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	1	c586f3a9-3133-44e6-9350-1a5080b35032_0
1d75dc98-2412-43e3-8d65-bacf6c684a87	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	f80fa106-5137-477f-80d2-8fa82a3b4380	3501d446-de5e-4ef2-bb06-e4820f5dc3d8	INTERVIEW_2	ONLINE	2026-05-08 03:03:00	2026-05-08 03:03:00				COMPLETED	2026-05-14 03:03:51.129	\N	f	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2	\N
fb48be98-698a-4676-8383-12328c26b837	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	f80fa106-5137-477f-80d2-8fa82a3b4380	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_2	OFFLINE	2026-05-15 06:00:00	2026-05-15 07:00:00	深圳市福田区长富金茂大厦1号楼5503深圳码隆智能科技有限公司			SCHEDULED	2026-05-14 03:36:01.491	\N	f	2db10b9f-fc8d-48cd-b99c-9414a5c2770d	3	24c51df6-3ab9-488f-a4ea-81bd6a7331e8_0
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.notifications (id, "userId", type, title, content, read, link, "createdAt") FROM stdin;
51052aed-cee1-4041-ba62-85cb15f685fa	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人刘永能，职位AI智能体架构师，第1轮	f	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-14 09:19:32.951
b7bd8e62-f65e-43d5-927b-44f9d608151b	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人曹奇，职位AI智能体架构师，第1轮	f	/interview-processes/33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2026-04-14 09:44:33.842
f1c2cad6-ad99-4b4d-9328-fbd27e89aa93	77bfd979-145a-45b2-b874-a63627cabce1	PROCESS_UPDATE	新一轮面试即将开始	候选人刘永能即将进入您的第3轮面试环节，职位AI智能体架构师	f	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-15 05:43:43.045
653eee3e-5997-4ce2-a8fc-13ea81f1c9c0	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人刘永能，职位AI智能体架构师，第3轮	f	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-15 05:44:59.212
cf1d4cdd-7aea-40e1-a86b-2a42f498326e	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人曹奇，职位AI智能体架构师，第2轮	t	/interview-processes/33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2026-04-14 10:00:39.008
210d0c4e-fa81-4c9e-a721-4727ab83f73e	b90a3c05-8ab8-453f-9850-f3768cdade2b	PROCESS_UPDATE	轮次面试已完成	候选人刘永能第1轮面试已完成，请确认下一步操作	t	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-14 09:29:49.832
99b615a9-e629-4632-add4-0f9fd0f1e0de	b90a3c05-8ab8-453f-9850-f3768cdade2b	PROCESS_UPDATE	轮次面试已完成	候选人刘永能第2轮面试已完成，请确认下一步操作	t	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-15 03:04:32.641
9414008a-d0ac-4c88-9a44-047b0c2fcc81	43a36a18-6230-4a1c-8e78-58b0c92ce415	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人萧晓霞，职位高级销售经理，第1轮	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:37:20.24
403493e9-c4ed-4e03-aaf4-c86b1f84e5c3	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人萧晓霞第1轮面试已完成，请确认下一步操作	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:42:08.022
0fdf60eb-4c59-4baa-8a2c-0372d67e2db4	9b1b4243-193c-47da-850c-1ca74f86a27f	PROCESS_UPDATE	新一轮面试即将开始	候选人萧晓霞即将进入您的第2轮面试环节，职位高级销售经理	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:42:32.498
cc16a62b-b2c4-49ae-8269-86de72e6f5ac	9b1b4243-193c-47da-850c-1ca74f86a27f	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人萧晓霞，职位高级销售经理，第2轮	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:42:55.925
69406544-5912-46d4-b710-223f263e121d	77bfd979-145a-45b2-b874-a63627cabce1	PROCESS_UPDATE	新一轮面试即将开始	候选人萧晓霞即将进入您的第3轮面试环节，职位高级销售经理	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:43:17.491
abd3ba43-e680-46c8-bf68-e39c00674251	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人萧晓霞，职位高级销售经理，第3轮	f	/interview-processes/cda3e8df-a08a-43a8-ba42-217d0bad11c4	2026-04-21 09:44:05.558
20c120b6-2924-4037-8214-2eeb3346a3a9	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人刘永能即将进入您的第2轮面试环节，职位AI智能体架构师	t	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-14 09:29:58.562
c4373446-b710-4c25-a4cd-9c884bb4cc66	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人刘永能，职位AI智能体架构师，第2轮	t	/interview-processes/120a543b-cb6a-4e01-aa08-2a6f6ae6e28f	2026-04-14 09:31:36.993
ff64bf1e-e1fb-413b-a7bf-bed58b719592	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人曹奇即将进入您的第2轮面试环节，职位AI智能体架构师	t	/interview-processes/33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2026-04-14 09:59:42.998
59ad8965-597f-455d-9cd0-881d4d18876c	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	面试时间调整	候选人曹奇面试时间已调整，请准时参加	t	/interviews/4fa94d00-ae24-4db9-ba46-e3dd71d0dd80	2026-04-15 10:13:15.019
d5a4688d-98ad-4bdc-952b-aa3d43698d86	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	面试时间调整	候选人曹奇面试时间已调整，请准时参加	t	/interviews/4fa94d00-ae24-4db9-ba46-e3dd71d0dd80	2026-04-15 11:12:53.733
1b446bf3-d791-46b4-a71f-bdc5ac69a882	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人曹奇，职位AI智能体架构师，第2轮	t	/interview-processes/33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2026-04-23 11:32:52.577
9f0cf337-e37e-4574-8987-4a611f0d3f2c	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人曹奇，职位AI智能体架构师，第2轮	t	/interview-processes/33b7fef3-029d-4a2e-b7bc-cfc4fcaa95ee	2026-04-23 12:49:47.751
a5d96f3c-02b4-4b02-8f1f-73e2788be7af	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人吴瑞煌，职位AI+教育智能硬件 软件产品经理，第1轮	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-04-29 08:44:56.093
81a8877d-51a7-456e-ab54-3ec0743e4d04	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人吴瑞煌第1轮面试已完成，请确认下一步操作	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-04-29 08:45:18.223
3aafb487-86ad-4cf0-88da-d22f3d0db2d6	5720b05a-36d2-4160-906e-f3212a29d1a6	PROCESS_UPDATE	新一轮面试即将开始	候选人吴瑞煌即将进入您的第2轮面试环节，职位AI+教育智能硬件 软件产品经理	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-04-29 08:45:23.13
cbfd9b87-1c65-4c40-b225-11398436dd79	5720b05a-36d2-4160-906e-f3212a29d1a6	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人吴瑞煌，职位AI+教育智能硬件 软件产品经理，第2轮	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-04-29 08:46:16.669
18289f2f-4a92-45ef-9ce7-cc3a98be12c7	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人吴瑞煌第2轮面试已完成，请确认下一步操作	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-05-06 06:35:44.978
ff1e4ca8-00df-4c43-8682-b4651741805d	77bfd979-145a-45b2-b874-a63627cabce1	PROCESS_UPDATE	新一轮面试即将开始	候选人吴瑞煌即将进入您的第3轮面试环节，职位AI+教育智能硬件 软件产品经理	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-05-06 06:36:35.489
47b40655-54a2-482c-a27c-33b515ae7939	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人吴瑞煌，职位AI+教育智能硬件 软件产品经理，第3轮	f	/interview-processes/d1cb5ab0-97ae-4756-902c-0e784762a52f	2026-05-06 06:38:40.737
6bd1892c-35af-43a6-b4f1-d87f0e3dbb26	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人陈世健，职位AI智能体架构师，第1轮	f	/interview-processes/ce94c19a-5bac-4bf3-ab74-761c917b54a4	2026-05-07 06:09:43.339
0063a3b5-d7cc-47c8-a0dd-f7606ba50cd1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人陈世健第1轮面试已完成，请确认下一步操作	f	/interview-processes/ce94c19a-5bac-4bf3-ab74-761c917b54a4	2026-05-07 06:10:04.918
871769d2-52a2-4b72-8c8d-50b0b447eef6	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人欧阳凌，职位AI智能体架构师，第1轮	f	/interview-processes/7d52ddab-84fa-46b1-98ab-6d3904b440cb	2026-05-07 06:16:36.661
bd91aaba-9581-496a-961e-2332b45b405b	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人罗健维，职位生产仓储专员，第1轮	f	/interview-processes/461e11b1-5421-48b9-adc7-95af5dc9017b	2026-05-07 08:21:51.152
e33496fc-5609-4a99-a056-d94e20dd50a1	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人罗健维第1轮面试已完成，请确认下一步操作	f	/interview-processes/461e11b1-5421-48b9-adc7-95af5dc9017b	2026-05-07 08:22:29.764
801be47c-6ee6-4705-97fd-bb133f77d288	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人陈世健第2轮面试已完成，请确认下一步操作	f	/interview-processes/ce94c19a-5bac-4bf3-ab74-761c917b54a4	2026-05-08 15:27:17.063
a780da76-2611-4f6a-9d95-9112fc73a937	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人陈世健即将进入您的第2轮面试环节，职位AI智能体架构师	t	/interview-processes/ce94c19a-5bac-4bf3-ab74-761c917b54a4	2026-05-07 06:10:10.491
901c921d-1005-4fd3-bc4e-b9fde1566a17	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人陈世健，职位AI智能体架构师，第2轮	t	/interview-processes/ce94c19a-5bac-4bf3-ab74-761c917b54a4	2026-05-07 06:14:55.63
a5945f68-fbfb-4729-8cfc-484726cb311c	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人欧阳凌即将进入您的第2轮面试环节，职位AI智能体架构师	t	/interview-processes/7d52ddab-84fa-46b1-98ab-6d3904b440cb	2026-05-07 06:16:54.179
6383f8e3-4144-4deb-9734-87ff625d9a99	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人欧阳凌，职位AI智能体架构师，第2轮	t	/interview-processes/7d52ddab-84fa-46b1-98ab-6d3904b440cb	2026-05-07 06:23:42.138
7d60920b-88ac-4ea6-9db6-ad96b20f34c2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人罗健维即将进入您的第2轮面试环节，职位生产仓储专员	t	/interview-processes/461e11b1-5421-48b9-adc7-95af5dc9017b	2026-05-07 08:22:40.46
b17d984e-8723-4077-9bef-c012113db6f2	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人罗健维，职位生产仓储专员，第2轮	t	/interview-processes/461e11b1-5421-48b9-adc7-95af5dc9017b	2026-05-07 08:24:03.202
c1aea1fd-8578-4ca5-9ff8-8179b21eec49	77bfd979-145a-45b2-b874-a63627cabce1	INTERVIEW_REMINDER	面试时间调整	候选人吴瑞煌面试时间已调整，请准时参加	f	/interviews/e58e5ff9-ac5e-49eb-b0b8-f28ede8e108d	2026-05-09 02:15:55.799
e3014074-6270-4d5f-964e-75f8100198ff	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人王彩月，职位AI+教育智能硬件 软件产品经理，第1轮	f	/interview-processes/640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2026-05-11 02:14:07.883
dde9606d-44b2-4477-8a63-86ead9ece3b8	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	PROCESS_UPDATE	新一轮面试即将开始	候选人王彩月即将进入您的第2轮面试环节，职位AI+教育智能硬件 软件产品经理	f	/interview-processes/640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2026-05-11 02:15:00.914
4d4ed701-f62d-409e-9755-e0e1435e2389	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人王彩月，职位AI+教育智能硬件 软件产品经理，第2轮	f	/interview-processes/640a9ce8-6cc2-4a00-a136-ea93f5ff3dc4	2026-05-11 02:16:19.915
ffef0ff8-5267-447f-8732-b752a7e8d6a5	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人李猛，职位AI+教育智能硬件 软件产品经理，第1轮	f	/interview-processes/77734990-16d2-4f97-9d51-fee644a737a9	2026-05-11 03:27:56.978
f8733bf5-6c97-4f93-a9eb-e341e1656e22	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	PROCESS_UPDATE	新一轮面试即将开始	候选人李猛即将进入您的第2轮面试环节，职位AI+教育智能硬件 软件产品经理	f	/interview-processes/77734990-16d2-4f97-9d51-fee644a737a9	2026-05-11 03:28:24.219
b3264ce0-b593-4404-84be-d6e2911850b3	2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人李猛，职位AI+教育智能硬件 软件产品经理，第2轮	f	/interview-processes/77734990-16d2-4f97-9d51-fee644a737a9	2026-05-11 03:30:21.436
9ea17384-04b9-4491-991f-39d992834dfe	4f0dd80b-c682-480a-ad58-9fbe08e547ad	PROCESS_UPDATE	轮次面试已完成	候选人罗健维第2轮面试已完成，请确认下一步操作	f	/interview-processes/461e11b1-5421-48b9-adc7-95af5dc9017b	2026-05-11 06:34:52.132
4512b45c-2fa8-4130-8e25-7a103659fc8c	4f0dd80b-c682-480a-ad58-9fbe08e547ad	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人朱建锟，职位测试工程师，第1轮	f	/interview-processes/2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2026-05-14 03:03:17.24
c210bfe6-452e-44dc-b650-757c15405d45	3501d446-de5e-4ef2-bb06-e4820f5dc3d8	PROCESS_UPDATE	新一轮面试即将开始	候选人朱建锟即将进入您的第2轮面试环节，职位测试工程师	f	/interview-processes/2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2026-05-14 03:03:34.877
9e292c67-bf97-4383-a6cb-c6e966cfcce7	3501d446-de5e-4ef2-bb06-e4820f5dc3d8	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人朱建锟，职位测试工程师，第2轮	f	/interview-processes/2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2026-05-14 03:03:59.203
46fd1d0d-0633-4e61-8bfc-84bd4bf1a7e7	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	PROCESS_UPDATE	新一轮面试即将开始	候选人朱建锟即将进入您的第3轮面试环节，职位测试工程师	f	/interview-processes/2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2026-05-14 03:34:50.775
9d0e046b-61ab-432b-8e37-ab8344f4a1df	3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	INTERVIEW_REMINDER	新面试安排	您有新面试：候选人朱建锟，职位测试工程师，第3轮	f	/interview-processes/2db10b9f-fc8d-48cd-b99c-9414a5c2770d	2026-05-14 03:36:12.209
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.positions (id, title, description, requirements, "salaryMin", "salaryMax", headcount, "hiredCount", "inProgressCount", status, location, "createdAt", "updatedAt") FROM stdin;
80304f3b-ce66-40b9-a5c0-0c4ccdb18853	AI智能体架构师	岗位职责 \n1、负责教育 AI 产品中智能体相关功能的技术方案设计与落地 \n2、跟踪 AI 技术发展趋势，评估新技术在业务场景中的应用可能性，为团队提供技术选型建议 \n3、负责 AI 与业务系统的集成方案设计，关注效果、成本和可维护性的平衡 \n4、设计和优化 AI 应用中的信息结构与交互策略，提升 AI 输出质量 \n5、管理 AI 开发小组，负责任务分配、进度把控和交付质量保障 \n6、与产品、测试等部门跨团队协作，将业务需求转化为可落地的技术方案 \n7、沉淀开发流程与最佳实践，带动团队提升 AI 开发效率 \n\n任职要求 \n基本条件 \n1、学历要求：本科及以上学历，计算机科学、人工智能、软件工程等相关专业优先 \n2、工作经验：3 年以上 AI/LLM 相关开发经验，1 年以上团队管理或技术负责人经验 \n3、项目经验：至少主导过 1 个 AI 产品/功能从 0 到 1 的完整交付周期 \n4、语言能力：流利的中文沟通能力，能阅读英文技术文档与论文 \n5、专业技能 \n①学习能力与 AI Native 热情（最看重） 对 AI 技术有发自内心的好奇心和热情，习惯性地关注和尝试新模型、新工具 • 能快速学习和吸收新技术，并主动将所学转化为团队可用的实践经验 • 认同“AI Native”的工作方式：先想“AI 能不能做”再想“怎么写代码” • 不满足于“够用就行”，有持续探索更优解的驱动力 \n②技术能力 • 对当前主流大语言模型的能力和边界有基本认知 • 有 Prompt 工程实践经验，能把业务需求转化为有效的 AI 交互策略 • 后端开发：Node.js / Python 至少熟练一门 • 了解常见的 AI 工程化方案，能设计合理的系统集成架构 \n③团队管理能力 • 有带过小团队的经验，能在快速变化的环境中带领团队保持节奏 • 具备跨部门协作和项目推进能力 \n6、加分项\n• 有教育行业背景，或参与过教育 AI 产品的落地\n• 是 Cursor / Claude Code 等 AI 编程工具的深度用户，日常工作已离不开 AI • 有从 0 到 1 设计 AI 工作流的经历 \n• 有带领团队完成技术转型的经历 \n• 乐于分享，习惯把自己的技术发现和思考整理给团队 简历如下	\N	30000	50000	1	0	0	OPEN	\N	2026-04-14 02:47:36.249	2026-04-14 02:47:36.249
aeeebdcd-507b-4ac9-9f3d-96ae48745d3f	高级销售经理	职责描述： \n1、 负责公司智慧教育产品及解决方案（智慧实验、智慧校园、智慧教室等）的商务、销售工作； \n2、 积极开拓、维护教育局、中小学校客户关系，深度挖掘需求，拓展销售业务，协同内外部团队成员达成销售目标；\n3、 实时关注市场动态，熟悉市场及行业现状，在智慧教育行业有独到的见解及营销方案；\n4、 积极配合市场宣传，协助市场活动，建立行业口碑； \n5、 识别项目、合同风险，确保合规。 \n\n任职要求： \n1、 统招本科及以上学历，市场营销或计算机相关专业；\n 2、 3-5年智慧教育行业销售/解决方案经验，有教育招投标经验和教育产品或解决方案销售成功案例，具备较好的行业洞察及资源； \n3、 具备较强的学习能力及客户谈判技巧，具备复杂项目处理能力，推动内部资源整合确保商务成功； \n4、 结果导向，主动负责，有较强的问题解决能力及抗压能力，团队合作能力强。	\N	\N	\N	1	0	0	OPEN	\N	2026-04-21 09:35:05.472	2026-04-21 09:35:05.472
65b53306-d103-424a-9fcb-e41cb4020166	AI+教育智能硬件 软件产品经理	岗位职责\n1. 产品规划与定义\n负责AI教育智能硬件产品的软件系统模块规划，包括交互逻辑、功能模块、学习路径设计等。\n结合用户学习场景（如课堂教学、实验操作、语言学习、个性化练习），定义AI驱动的核心功能。\n2. AI能力落地\n与算法团队协作，将多模态大模型（LLM）等AI技术转化为可落地的教育功能。\n设计数据闭环机制，通过用户学习行为数据持续优化模型效果与推荐策略。\n3. 软硬一体化体验\n协调硬件、嵌入式、App、云端等多端协同，确保软件功能在硬件设备上的流畅性与一致性。\n参与硬件选型（如屏幕、麦克风阵列、摄像头）的软件需求输入，保证AI功能硬件适配性。\n4. 用户与市场导向\n 深入理解K12学生、家长、教师的使用痛点，通过用户调研、数据分析驱动产品迭代。\n   跟踪AI教育行业趋势（如大模型在教育中的应用、多模态交互），输出竞品分析与创新方案。\n5. 项目推进\n独立完成PRD撰写、原型设计（Figma/Axure）、需求评审及开发跟进。\n协同设计、研发、测试、运营团队，把控产品版本节奏与交付质量。\n6. 利用AI辅助产品工作（新增）\n主动将AI工具（如ChatGPT、Claude、Copilot、Midjourney、Gamma等）融入产品工作流，包括但不限于：\n    用AI辅助用户需求分析与访谈纪要提炼；\n  用AI生成PRD初稿、用户故事、验收用例；\n  用AI快速制作产品原型示意或交互文案；\n  用AI分析用户行为数据、生成可视化洞察报告。\n\n任职要求\n本科及以上学历，计算机、心理学、教育技术、人机交互等相关专业优先。\n3年以上软件产品经理经验，至少有一段完整产品从0到1的上线经历。\n熟悉至少一种AI技术（语音/视觉/NLP/推荐），理解模型能力边界与数据标注逻辑。\n了解K12学习场景、教材体系或教学逻辑，有教育APP、学习机、智能教辅产品经验者优先。\n了解硬件产品开发流程，能与硬件/嵌入式工程师有效沟通资源与限制。\n熟练使用SQL或数据分析工具，能通过用户行为数据指导产品优化。\n能高效跨团队协作，对产品细节有执念，能快速试错迭代。\n日常工作中高频使用至少2种AI工具（如LLM类、绘图类、自动化分析类），并能举例说明其带来的效率提升。\n\n加分项\n 有大模型（LLM）在教育场景（如作文批改、口语对话、解题引导）的实际落地经验。\n 熟悉儿童发展心理学或认知科学理论，能将教育理念转化为产品机制。\n 做过硬件系统级软件（如Android系统定制、Launcher、系统设置/家长管控模块）。\n 自己开发过简单原型或写过脚本（Python/Swift等）验证想法。\n 对AI教育有强烈热情，关注国内外AI教育产品	\N	\N	\N	1	0	0	OPEN	\N	2026-04-29 08:43:14.357	2026-04-29 08:43:14.357
5c0a8176-d97e-43ac-a700-bfc9210c772b	生产仓储专员	【职位描述】\n1.大专及以上学历，物流，仓储管理等相关专业优先。\n2.有电子产品，智能硬件，精密仪器等行业生产或仓库经验者优先。\n3.熟悉仓库管理流程(收，发，存，盘)，了解FIFO等库存管理原则。\n4.能熟练操作电脑及Office办公软件，能使用WMS或ERP系统。\n【任职要求】\n1.大专及以上学历，物流，仓储管理等相关专业优先。\n2.责任心强，工作细致严谨：对数字敏感，能保证库存数据的极高准确性。\n3.吃苦耐劳，积极主动：能适应仓库的工作环境，并能完成一定的体力工作。\n4.良好的沟通能力和团队合作精神，与公司各部门顺畅协作完成工作。\n5.学习能力强：能够快速熟悉产品，适应智能化管理工具。\n6.注重安全和条理：有强烈的安全意识，做事有条不紊。\n7.能快接受、熟悉并使用AI工具，提效工作效率。	\N	\N	\N	1	0	0	OPEN	\N	2026-05-07 08:21:18.371	2026-05-07 08:21:18.371
f80fa106-5137-477f-80d2-8fa82a3b4380	测试工程师	【职位描述】\n1.负责核心产品全流程质量保障，参与需求评审，制定测试计划，设计测试用例，执行测试并输出测试报告。\n2.负责前后端服务、移动端的功能、接口、兼容性、性能、压力等测试，保障产品稳定性。\n3.搭建、维护自动化测试体系，提升测试效率与用例覆盖率。\n4.全程跟踪缺陷，推动问题闭环，定期输出质量分析与改进建议。\n5.参与 CI/CD 流程建设，推进测试左移，支撑持续集成与快速交付\n\n【任职要求】\n1.计算机及相关专业本科及以上学历。\n2.3 年及以上软件 / 系统测试相关工作经验。\n3.熟练使用 Postman / Apifox / JMeter 等接口测试工具，掌握 Python / JavaScript 至少一门脚本语言。\n4.熟悉 Linux 环境，能独立完成环境部署、日志分析与问题定位；熟练使用 SQL 进行数据验证。\n5.能够使用 AI 编程工具（Cursor / Copilot / Claude Code）快速编写脚本、生成用例，提升测试效率。\n6.熟练使用 Jira / 禅道等缺陷管理与项目协作工具。	\N	\N	\N	1	0	0	OPEN	\N	2026-05-14 02:59:10.538	2026-05-14 02:59:10.538
\.


--
-- Data for Name: resume_files; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.resume_files (id, "candidateId", "fileName", "fileType", "fileSize", "filePath", "fileUrl", "uploadedBy", "isActive", "uploadedAt") FROM stdin;
f60a6aff-9077-4191-b799-f5e584b7345a	4d866173-d567-484f-a2fe-39cf0523dde8	ãAI æºè½ä½é«çº§å·¥ç¨å¸_æ¶æå¸_æ·±å³ 30-50Kãèé­ 10å¹´ä»¥ä¸.pdf	application/pdf	259463	/app/uploads/resumes/4d866173-d567-484f-a2fe-39cf0523dde8_1776077311643.pdf	/candidates/resumes/4d866173-d567-484f-a2fe-39cf0523dde8	b90a3c05-8ab8-453f-9850-f3768cdade2b	t	2026-04-13 10:48:31.645
edd53515-b50a-49e8-82f6-8259f6ed99e0	2c16f1b1-543c-4f5b-8e44-55d5af77966a	ãAI æºè½ä½é«çº§å·¥ç¨å¸_æ¶æå¸_æ·±å³ 30-50Kãæ¹å¥ 3å¹´.pdf	application/pdf	207419	/app/uploads/resumes/2c16f1b1-543c-4f5b-8e44-55d5af77966a_1776133409664.pdf	/candidates/resumes/2c16f1b1-543c-4f5b-8e44-55d5af77966a	b90a3c05-8ab8-453f-9850-f3768cdade2b	t	2026-04-14 02:23:29.667
ee2ac9e6-f55c-439f-81f0-ce5c32665f20	595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	ãAI æºè½ä½é«çº§å·¥ç¨å¸_æ¶æå¸_æ·±å³ 30-50Kãåæ°¸è½ 10å¹´ä»¥ä¸.pdf	application/pdf	554437	/app/uploads/resumes/595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0_1776134730345.pdf	/candidates/resumes/595d4aa5-4dd4-491d-b6da-6f1e7a6df8d0	b90a3c05-8ab8-453f-9850-f3768cdade2b	t	2026-04-14 02:45:30.347
9ca2c385-0769-4e7d-bc7e-a0649133ad68	15b2a0ff-f2d4-4787-9cdf-01f6f055556b	è§æé_XIAO Xiaoxia Jasmine_CV.pdf	application/pdf	342807	/app/uploads/resumes/15b2a0ff-f2d4-4787-9cdf-01f6f055556b_1776764069713.pdf	/candidates/resumes/15b2a0ff-f2d4-4787-9cdf-01f6f055556b	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-04-21 09:34:29.742
72df2cf5-a6ac-4b57-9017-650ec29fb66a	b596dd09-d74b-4946-9ef1-cd447332984d	ãAI+æè²æºè½ç¡¬ä»¶ è½¯ä»¶äº§åç»ç_æ·±å³ 11-20Kãå´çç 10å¹´ä»¥ä¸.pdf	application/pdf	149003	/app/uploads/resumes/b596dd09-d74b-4946-9ef1-cd447332984d_1777451931263.pdf	/candidates/resumes/b596dd09-d74b-4946-9ef1-cd447332984d	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-04-29 08:38:51.267
afd94b09-9e8a-451f-b846-230c9f6955ea	77a3b50c-dc9a-4927-822f-2bd9e306d489	ãAI æºè½ä½é«çº§å·¥ç¨å¸_æ¶æå¸_æ·±å³ 30-50Kãéä¸å¥ 5å¹´.pdf	application/pdf	1342607	/app/uploads/resumes/77a3b50c-dc9a-4927-822f-2bd9e306d489_1778134079329.pdf	/candidates/resumes/77a3b50c-dc9a-4927-822f-2bd9e306d489	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-07 06:07:59.341
ec4a925b-2f64-41e6-9611-b87d8e50d4e4	cc902c14-ccfa-47ad-83ae-ad03563001ac	ãAI æºè½ä½é«çº§å·¥ç¨å¸_æ¶æå¸_æ·±å³ 30-50Kãæ¬§é³å 10å¹´ä»¥ä¸.pdf	application/pdf	247138	/app/uploads/resumes/cc902c14-ccfa-47ad-83ae-ad03563001ac_1778134101009.pdf	/candidates/resumes/cc902c14-ccfa-47ad-83ae-ad03563001ac	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-07 06:08:21.011
da2f2914-3832-47dd-b8d4-33bb0acd0625	38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	ç½å¥ç»´çç®å .pdf	application/pdf	96074	/app/uploads/resumes/38a5b115-d7f4-4e74-b9d4-823fa5a40ea2_1778142021609.pdf	/candidates/resumes/38a5b115-d7f4-4e74-b9d4-823fa5a40ea2	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-07 08:20:21.614
a7279b09-3306-4101-bc46-23c4d271f758	78ae8cf0-fe2b-4526-8dc6-1267a4d00439	ãAI+æè²æºè½ç¡¬ä»¶ è½¯ä»¶äº§åç»ç_æ·±å³ 11-20Kãçå½©æ 6å¹´.pdf	application/pdf	354800	/app/uploads/resumes/78ae8cf0-fe2b-4526-8dc6-1267a4d00439_1778465213015.pdf	/candidates/resumes/78ae8cf0-fe2b-4526-8dc6-1267a4d00439	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-11 02:06:53.06
52dd9d01-2832-494c-8bed-4172d4ff6d3f	56910296-ec6c-4dac-94ad-0e7f2e8cba26	ãAI+æè²æºè½ç¡¬ä»¶ è½¯ä»¶äº§åç»ç_æ·±å³ 11-20Kãæç 10å¹´.pdf	application/pdf	726303	/app/uploads/resumes/56910296-ec6c-4dac-94ad-0e7f2e8cba26_1778470028163.pdf	/candidates/resumes/56910296-ec6c-4dac-94ad-0e7f2e8cba26	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-11 03:27:08.166
cd12ef60-c2f1-4967-b866-91c30736d482	9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	ãæµè¯å·¥ç¨å¸_æ·±å³ 11-20Kãæ±å»ºé 4å¹´.pdf	application/pdf	212919	/app/uploads/resumes/9dd8d3bf-8ab8-4203-b654-95ac35bb64ee_1778727464632.pdf	/candidates/resumes/9dd8d3bf-8ab8-4203-b654-95ac35bb64ee	4f0dd80b-c682-480a-ad58-9fbe08e547ad	t	2026-05-14 02:57:44.637
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.system_settings (key, value, description, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: moka
--

COPY public.users (id, username, password, name, email, role, "avatarUrl", "createdAt", "updatedAt", "isActive", "feishuOuId") FROM stdin;
b90a3c05-8ab8-453f-9850-f3768cdade2b	hr	$2b$10$KsoeV4sacJIZk1fZc3iseOa9RlNyl4peOAyjzK2lwwzXJtcw4Mdy6	张HR	hr@company.com	HR	\N	2026-04-09 02:18:36.41	2026-04-09 02:18:36.41	t	\N
6e9397fd-4522-4059-b7f9-44982f89adcf	interviewer	$2b$10$Gc7potpIcdggjtSgMG615OIhzW4AlHaJXm/tGNEKDc19/KxwyXuKW	李面试官	interviewer@company.com	INTERVIEWER	\N	2026-04-09 02:18:36.651	2026-04-09 02:18:36.651	t	\N
77bfd979-145a-45b2-b874-a63627cabce1	wusumin	$2b$10$61jPL7FEeBE7BG1Ccpd38.mbI2283kUIUbkzT1Hi71zvh9KJUg4q.	吴素敏	suswoo@malong.com	INTERVIEWER	\N	2026-04-14 09:18:04.837	2026-04-14 09:18:04.837	t	\N
e0d59683-73d7-4306-a967-d023994d533e	huangdinglong	$2b$10$go8SWf.xBXRWVY1EgqVzZO5kWHxQkOlF9GJB4dKFqL6olFV68zPjG	黄鼎隆	dlong@malong.com	INTERVIEWER	\N	2026-04-14 09:18:38.083	2026-04-14 09:18:38.083	t	\N
4f0dd80b-c682-480a-ad58-9fbe08e547ad	jinxuelei	$2b$10$wkMah4FVwCZ1lTefs76i0.QbvoICZF9NHMnJ5FdwJadrEfB5H1XsS	金雪蕾	xuejin@malong.com	HR	\N	2026-04-14 09:17:14.127	2026-04-14 09:17:14.127	t	ou_4238395478e905c252ea8005898efffb
3cded7d6-3ef4-4cee-ad6f-7fd2dff75a37	xiaoshijie	$2b$10$GzH5kXrsQAuum2lMqR.3IOzeyd.pg3VsjEHjOI3t0eIjuFxDm3IO.	肖仕杰	shaxiao@malong.com	INTERVIEWER	\N	2026-04-14 09:16:15.691	2026-04-21 09:15:16.277	t	ou_3514efa09be4dfcd7a07a25031093599
43a36a18-6230-4a1c-8e78-58b0c92ce415	chenjiyan	$2b$10$2GFuGacscTDkWCisnrYdWu6BVjD12EshfMdGGir7z669dVzUdQf6K	陈继岩	jyc@malong.com	HR	\N	2026-04-14 02:24:24.818	2026-04-21 09:24:16.918	t	ou_7b097de34f1dee5658509088eb299af9
9b1b4243-193c-47da-850c-1ca74f86a27f	huhao	$2b$10$XhwgU.LZ5DLL1SmGdQIWJ.mN8Jpotl/S8.LsMh02suYUmxyUaULQG	胡浩	huhao@malong.com	INTERVIEWER	\N	2026-04-21 09:35:49.564	2026-04-21 09:35:49.564	t	\N
5720b05a-36d2-4160-906e-f3212a29d1a6	zhaocongzhi	$2b$10$hWeS60PAG/DiHyym9HSsJelMF2VGDAl1ut2JblK3u6w5ym6B18fQq	赵从志	zhaocongzhi@malong.com	INTERVIEWER	\N	2026-04-29 08:44:20.443	2026-04-29 08:44:20.443	t	\N
2b0ae1ba-dcf4-4a71-b82b-9c9b571af59b	liaoxiaoxiao	$2b$10$DQ9qEl2GsUahtEuQpvMlhe0VRF5uFduFXV0MrXtNhdNGeDnRfwe5C	廖逍虓	liaoxiaoxiao@malong.com	INTERVIEWER	\N	2026-05-11 02:11:01.071	2026-05-11 02:11:01.071	t	\N
3501d446-de5e-4ef2-bb06-e4820f5dc3d8	liuzhenxing	$2b$10$7ZuBU1.7EBkKGW8rd0BbdOfm75qwmCnlOP7Lw4EOEDyy5UweBKfMm	刘振兴	fraliu@malong.com	INTERVIEWER	\N	2026-05-14 03:01:08.481	2026-05-14 03:01:08.481	t	\N
\.


--
-- Name: InterviewEmailLog InterviewEmailLog_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public."InterviewEmailLog"
    ADD CONSTRAINT "InterviewEmailLog_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: ai_diagnoses ai_diagnoses_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.ai_diagnoses
    ADD CONSTRAINT ai_diagnoses_pkey PRIMARY KEY (id);


--
-- Name: candidate_mentions candidate_mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_mentions
    ADD CONSTRAINT candidate_mentions_pkey PRIMARY KEY (id);


--
-- Name: candidate_status_history candidate_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_status_history
    ADD CONSTRAINT candidate_status_history_pkey PRIMARY KEY (id);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: feedback_tokens feedback_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.feedback_tokens
    ADD CONSTRAINT feedback_tokens_pkey PRIMARY KEY (id);


--
-- Name: interview_feedbacks interview_feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_feedbacks
    ADD CONSTRAINT interview_feedbacks_pkey PRIMARY KEY (id);


--
-- Name: interview_processes interview_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_processes
    ADD CONSTRAINT interview_processes_pkey PRIMARY KEY (id);


--
-- Name: interview_rounds interview_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_rounds
    ADD CONSTRAINT interview_rounds_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_processId_roundNumber_key; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_processId_roundNumber_key" UNIQUE ("processId", "roundNumber");


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: resume_files resume_files_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.resume_files
    ADD CONSTRAINT resume_files_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: InterviewEmailLog_candidateId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "InterviewEmailLog_candidateId_idx" ON public."InterviewEmailLog" USING btree ("candidateId");


--
-- Name: InterviewEmailLog_interviewId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "InterviewEmailLog_interviewId_idx" ON public."InterviewEmailLog" USING btree ("interviewId");


--
-- Name: InterviewEmailLog_sentAt_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "InterviewEmailLog_sentAt_idx" ON public."InterviewEmailLog" USING btree ("sentAt");


--
-- Name: ai_diagnoses_processId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "ai_diagnoses_processId_idx" ON public.ai_diagnoses USING btree ("processId");


--
-- Name: ai_diagnoses_processId_roundNumber_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX "ai_diagnoses_processId_roundNumber_key" ON public.ai_diagnoses USING btree ("processId", "roundNumber");


--
-- Name: candidate_mentions_candidateId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "candidate_mentions_candidateId_idx" ON public.candidate_mentions USING btree ("candidateId");


--
-- Name: candidate_mentions_interviewerId_status_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "candidate_mentions_interviewerId_status_idx" ON public.candidate_mentions USING btree ("interviewerId", status);


--
-- Name: candidate_status_history_candidateId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "candidate_status_history_candidateId_idx" ON public.candidate_status_history USING btree ("candidateId");


--
-- Name: candidate_status_history_createdAt_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "candidate_status_history_createdAt_idx" ON public.candidate_status_history USING btree ("createdAt");


--
-- Name: candidates_name_phone_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX candidates_name_phone_key ON public.candidates USING btree (name, phone);


--
-- Name: feedback_tokens_interviewId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "feedback_tokens_interviewId_idx" ON public.feedback_tokens USING btree ("interviewId");


--
-- Name: feedback_tokens_interviewId_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX "feedback_tokens_interviewId_key" ON public.feedback_tokens USING btree ("interviewId");


--
-- Name: feedback_tokens_token_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX feedback_tokens_token_idx ON public.feedback_tokens USING btree (token);


--
-- Name: feedback_tokens_token_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX feedback_tokens_token_key ON public.feedback_tokens USING btree (token);


--
-- Name: interview_rounds_processId_roundNumber_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX "interview_rounds_processId_roundNumber_key" ON public.interview_rounds USING btree ("processId", "roundNumber");


--
-- Name: notifications_userId_read_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "notifications_userId_read_idx" ON public.notifications USING btree ("userId", read);


--
-- Name: resume_files_candidateId_idx; Type: INDEX; Schema: public; Owner: moka
--

CREATE INDEX "resume_files_candidateId_idx" ON public.resume_files USING btree ("candidateId");


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: moka
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: InterviewEmailLog InterviewEmailLog_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public."InterviewEmailLog"
    ADD CONSTRAINT "InterviewEmailLog_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: InterviewEmailLog InterviewEmailLog_interviewId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public."InterviewEmailLog"
    ADD CONSTRAINT "InterviewEmailLog_interviewId_fkey" FOREIGN KEY ("interviewId") REFERENCES public.interviews(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: candidate_mentions candidate_mentions_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_mentions
    ADD CONSTRAINT "candidate_mentions_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: candidate_mentions candidate_mentions_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_mentions
    ADD CONSTRAINT "candidate_mentions_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: candidate_mentions candidate_mentions_mentionedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_mentions
    ADD CONSTRAINT "candidate_mentions_mentionedById_fkey" FOREIGN KEY ("mentionedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: candidate_status_history candidate_status_history_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_status_history
    ADD CONSTRAINT "candidate_status_history_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: candidate_status_history candidate_status_history_changedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidate_status_history
    ADD CONSTRAINT "candidate_status_history_changedBy_fkey" FOREIGN KEY ("changedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: candidates candidates_positionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT "candidates_positionId_fkey" FOREIGN KEY ("positionId") REFERENCES public.positions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: feedback_tokens feedback_tokens_interviewId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.feedback_tokens
    ADD CONSTRAINT "feedback_tokens_interviewId_fkey" FOREIGN KEY ("interviewId") REFERENCES public.interviews(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback_tokens feedback_tokens_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.feedback_tokens
    ADD CONSTRAINT "feedback_tokens_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_feedbacks interview_feedbacks_interviewId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_feedbacks
    ADD CONSTRAINT "interview_feedbacks_interviewId_fkey" FOREIGN KEY ("interviewId") REFERENCES public.interviews(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_feedbacks interview_feedbacks_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_feedbacks
    ADD CONSTRAINT "interview_feedbacks_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_processes interview_processes_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_processes
    ADD CONSTRAINT "interview_processes_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_processes interview_processes_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_processes
    ADD CONSTRAINT "interview_processes_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_processes interview_processes_positionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_processes
    ADD CONSTRAINT "interview_processes_positionId_fkey" FOREIGN KEY ("positionId") REFERENCES public.positions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_rounds interview_rounds_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_rounds
    ADD CONSTRAINT "interview_rounds_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interview_rounds interview_rounds_processId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interview_rounds
    ADD CONSTRAINT "interview_rounds_processId_fkey" FOREIGN KEY ("processId") REFERENCES public.interview_processes(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interviews interviews_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interviews interviews_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: interviews interviews_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interviews interviews_positionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_positionId_fkey" FOREIGN KEY ("positionId") REFERENCES public.positions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: interviews interviews_processId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT "interviews_processId_fkey" FOREIGN KEY ("processId") REFERENCES public.interview_processes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resume_files resume_files_candidateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.resume_files
    ADD CONSTRAINT "resume_files_candidateId_fkey" FOREIGN KEY ("candidateId") REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resume_files resume_files_uploadedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: moka
--

ALTER TABLE ONLY public.resume_files
    ADD CONSTRAINT "resume_files_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict mu8x2NmCzIEpRhRTY46LXFzBcUVa1ZM9ablYgyYZO0lcCMkP9obitsNwfH3Qvnt

